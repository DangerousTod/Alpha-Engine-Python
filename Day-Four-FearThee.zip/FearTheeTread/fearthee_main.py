
#######################################################################################################
#         developed by Jonathan Engwall, October of 2018 in Tijuana, MX                               #
#               PYTHON CMD CRUD MUD: FEAR THEE TREAD INTERACTIVE FICTION                              #
#         	ENGWALLJONATHANTHEREAL@GMAIL.COM **2018**                                             #
#######################################################################################################

import textwrap
import sys
import os
import random
import math
import csv
import functools
#import pandas

from time import sleep
from FearTheeZoneMap import *
from masterList import *
#from memo import *

from Items import *
from Players import *
from Lists import *
from Rooms import *

screen_width = 80

combat_state = 0
combat_round = 0

#######################################################################################################
#                                                                                                     #
#                                          make the player                                            #
#######################################################################################################

class thing:
  def __init__(self):
    self.name = name
    self.contents = contents

class backpack:
  def __init_(thing):
    backpack.name = ''
    backpack.contents = []

class living:
  def __init__(self):
    self.name = name
    self.location = location

class player:
  def __init__(living):
    player.name = ''
    player.attack = 2
    player.magic = 1
    player.health = 110
    player.location = '1'
    player.card = ''
    player.game_over = False

  def my_player_get_attack():
    my_player.name = my_player.name
    
    file = open('./Players/' + my_player.name + '/holding.txt','r')
    my_weapons = file.read()
    if 'bronze sword' in my_weapons:
      player.attack += 5
    elif 'shovel' in my_weapons:
      player.attack += 6
    elif 'wand' in my_weapons:
      player.attack += 2
      player.magic += 1
    elif 'thirty silver coins' in my_weapons:
      player.attack += 1
    else:
      prompt()
    file.close()
    file = open('./Players/' + my_player.name + '/wearing.txt','r')
    my_armor = file.read()
    if 'cloak' in my_armor:
      player.attack += 5
    if 'pendant of philemon' in my_armor:
      player.attack += 1
      player.magic += 5
    file.close()
    playerattack = (int(player.attack) + int(player.magic))
    return playerattack

  def my_player_get_weapon():
    my_player.name = my_player.name
    playerweapon = ''
    file = open('./Players/' + my_player.name + '/holding.txt','r')
    my_weapons = file.read()
    if 'bronze sword' in my_weapons:
      playerweapon = 'bronze sword'
    elif 'shovel' in my_weapons:
      playerweapon = 'shovel'
    elif 'wand' in my_weapons:
      playerweapon = 'wand'
    else:
      prompt()
    file.close()
    return playerweapon

  def my_player_get_dam_mesg():
    my_player.name = my_player.name
    player_dam_mesg = []
    file = open('./Players/' + my_player.name + '/holding.txt','r')
    my_weapons = file.read()
    if 'bronze sword' in my_weapons:
      player_dam_mesg = ['land a wild slash','open a deep cut','sink in a nice jab']
    elif 'shovel' in my_weapons:
      player_dam_mesg = ['make contact with a solid whack','send a split down the middle','swing upward and land a hard smack']
    elif 'wand' in my_weapons:
      player_dam_mesg = ['send a sizzling blast','call up a cone of freeze','summon a terrific blast']
    else:
      prompt()
    file.close()
    return player_dam_mesg

#######################################################################################################
#                                                                                                     #
#                                          enemy options and global                                   #
#######################################################################################################

class vampire:
  def __init__(self):

    self.name = 'Vampire'
    self.attack = 6
    self.health = 300
    self.location = 'Tropy_Room'
    self.dead = False

class zombie:
  def __init__(self):

    self.name = 'zombie'
    self.attack = 5
    self.health = 50
    self.location = 'Kitchen'
    self.dead = False

class bat:
  def __init__(self):

    self.name = 'bat'
    self.attack = 8
    self.health = 200
    self.location = 'Study'
    self.dead = False

class ghost:
  def __init__(self):

    self.name = 'ghost'
    self.attack = 1
    self.health = 400
    self.location = 'Stairway'
    self.dead = False

global my_player
my_player = player()

global playername
playername = my_player.name

global ai
ai = vampire()
ai = zombie()
ai = bat()
ai = ghost()

#######################################################################################################
#                                                                                                     #
#                                          necc. introduction art                                     #
#######################################################################################################

def get_backpack_contents():
  file = open('./Lists/player_card.txt','r')
  contents = file.read()
  print(contents)
  file.close()
  my_player.name = input("Choose the player to resume from this list\nChoose player: \n")

  file = open('./Lists/player_card.txt','r')
  strict = file.read()

  if my_player.name.lower() in strict.lower():
    file.close()
    hold_ready(playername)
  else:
    file.close()
    os.system('clear')
    message = "Player not found.\nRemember to match spelling and capitalization."
    title_screen_message(message)

def hold_ready(playername):
  file = open('./Players/' + my_player.name +'/holding.txt','r')
  file.close()
  wear_ready(playername)
def wear_ready(playername):
  file = open('./Players/' + my_player.name + '/wearing.txt','r')
  file.close()
  inv_ready(playername)
def inv_ready(playername):
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  file.close()
  list_ready(playername)
def list_ready(playername):
  file = open('./Players/' + my_player.name + '/treasuryList.txt','r')
  file.close()
  my_player.name = my_player.name
  file = open('./Players/' + my_player.name + '/startlocation.txt','r')
  startlocation = file.read()
  file.close()
  if '1' in startlocation:
    run_game(playername)
  else:
    print_start_location(playername)
 #tag

def print_start_location(playername):
  with open('./Players/' + my_player.name + '/startlocation.txt') as location_line:
    csv_reader = csv.reader(location_line, delimiter= ',')
    line_count = 0
    for row in csv_reader:

      new_start = ('' + (f'{"".join(row)}' + ''))
      line_count += 1

    restart(new_start)
def restart(new_start):
  my_player.location = new_start
  playerlocation = my_player.location.lower()
  print('\n' + my_player.location.upper() + '')
  print('' + zonemap[new_start][DESCRIPTION] + ' ')
  print('' + zonemap[new_start][ITEM] + ' ')
  main_game_loop()

def title_screen_message(message):
  print('\n')
  print('' + message + '\n')
  print('WELCOME TO: ')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('000000           NEW GAME        EXIT      or     RESUME                  000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000\n')
  title_screen_selections()

def title_screen_selections():
  choice = input("Command: ")
  while choice.lower() in ['new game','exit','resume']:
    if choice.lower() == ("exit"):
      sys.exit()
    elif choice.lower() == ("new game"):
      setup_game()
    elif choice.lower() == ("resume"):
      get_backpack_contents()
    else:
      title_screen()
      
    while choice.lower() not in ['new game', 'exit','resume']:
      print("Please enter a valid command: New Game - Exit - Resume")
      choice = input("Command: ")
      if choice.lower() == ("exit"):
        sys.exit()
      elif choice.lower() == ("new game"):
        setup_game()
      elif choice.lower() == ("resume"):
        get_backpack_contents()
      else:
        title_screen()

def title_screen():
  os.system('clear')
  print('\n')
  print('WELCOME TO: ')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('000000           NEW GAME        EXIT      or     RESUME                  000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000\n')
  title_screen_selections()

# '''
# ##  ##  ##   ## #### ## ## ##
# ###########  ## ########## ##
# ## ##### ##   #  ## ## ##  ##
# ### ### ###  ## #############
# ###########   #            #
# '''

ZONENAME= ''
DESCRIPTION = 'description'
EXAMINATION = 'examine'
SOLVED = False
NORTH = 'north'
SOUTH = 'south'
EAST = 'east'
WEST = 'west'
EXIT = 'escape'
DEATH = 'death'
ESCAPE = 'escape'

solved_places = {'Top Left Corner Room':False, 'Lower Left Room':False, 'Top Right Room':False, 'Lower Right Room':False, } # '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                }

#######################################################################################################
#                                                                                                     #
#                                          game CMD handlers                                          #
#######################################################################################################

def print_location():
  playerlocation = my_player.location.lower()
#  print('\n' + my_player.location.upper() + '')
  print('' + zonemap[my_player.location][DESCRIPTION] + ' ')
#  print('' + zonemap[my_player.location][ITEM] + ' ')
  prompt()

def movement_handler(destination):

  if destination.strip():
    os.system('clear')
#    print('\n\n' + 'You enter the ' + destination + '.')
    my_player.location = destination
    print_location() 
  else:
    print('\nSorry...You cannot go that direction.\n')
    my_player.location = my_player.location
    prompt()

def game_over(destination):
  if destination.strip():
    os.system('clear')
#    print('\n\n' + 'You enter the ' + destination + '.')
    my_player.location = destination
#    print('\n' + my_player.location.upper() + '')
    print('' + zonemap[my_player.location][DESCRIPTION] + ' ')
#    print('' + zonemap[my_player.location][EXAMINATION] + ' ')
    my_player.game_over == True
    sys.exit()

def player_look():
  os.system('clear')
  playerlocation = my_player.location.lower()
#  print('\n' + my_player.location.upper() + '')
  print('' + zonemap[my_player.location][DESCRIPTION] + '   ')
#  print('' + zonemap[my_player.location][ITEM] + ' ')
  prompt()

#######################################################################################################
#                                                                                                     #
#                                          combat and logic for AI                                    #
#######################################################################################################

 ################################################################################
#                                                                                #
#                          OUR VILLAINS                                          #
# ai = bats(Bats, 10, 20, 'Great_Hall', False, ['gold coin'])                    #
# ai = vampire(Vampire, 15, 75, 'Trophy_Room', False, ['sunscreen', 'wand'])     #
# ai = zombie(Zombie, 5, 30, 'Kitchen', False, ['old boots','copper key'])       #
#                                                                                #
 ################################################################################

def ai_intercept(combat_round, my_player, ai, playerlocation):
  playerlocation = ai.location.lower()
  battleground = ai.location.lower()
  playerlocation = my_player.location.lower()
  print("" + str(ai.name.upper()) + " has found you!\n")
  print("The mad beast looks at you for a moment...\n")
  print( "" + str(ai.name.upper()) + " attacks!!!\n")
  combat_state = 1
  hand_to_hand_combat(combat_round, my_player, ai, battleground, playerlocation)

def player_move(myQuarter):
  print('North - South - East - West - Up - Down')
  ask = "Choose a direction: "
  destination = input(ask)
  destinations = ['north', 'south', 'east', 'west','up','down']
  if destination in ['north']:
    destination = zonemap[my_player.location][NORTH]
    movement_handler(destination)
  elif destination in ['south']:
    destination = zonemap[my_player.location][SOUTH]
    movement_handler(destination)
  elif destination in ['east']:
    destination = zonemap[my_player.location][EAST]
    movement_handler(destination)
  elif destination in ['west']:
    destination = zonemap[my_player.location][WEST]
    movement_handler(destination)
  elif destination in ['up']:
    destination = zonemap[my_player.location][UP]
    movement_handler(destination)
  elif destination in ['down']:
    destination = zonemap[my_player.location][DOWN]
    movement_handler(destination)
  elif destination in ['escape']:
    destination = zonemap[my_player.location][EXIT]
    game_over(destination)
  else:
    print("Where is that?\nYou stay where you are.\n")

#######################################################################################################
#                                                                                                     #
#                                          combat loop basic                                          #
#######################################################################################################

def ai_fight(my_player, ai, battleground, playerlocation):
  combat_round = 0
  combat_state = 1
  combat_round = combat_round
  while combat_state == 1:
    if battleground != playerlocation:
      if combat_state != 0:
        time.sleep(0.02)
        ai_intercept(combat_round, my_player, ai, playerlocation)
      continue
    else:
      combat_state = 1
      hand_to_hand_combat(combat_round, my_player, ai, battleground, playerlocation)
    
def hand_to_hand_combat(combat_round, my_player, ai, battleground, playerlocation):
  combat_state = 1
  combat_round += 1
  playerattack = player.my_player_get_attack()
  playerweapon = player.my_player_get_weapon()
  player_dam_mesg = player.my_player_get_dam_mesg()
  while combat_state == 1:
    if my_player.health > 0:
      if ai.health > 0:
        
        player_dam_math = ((int(playerattack)) * (random.randint(5, 10))) - ((int(ai.attack)) * (random.randint(1, 4)))
        ai_dam_math = ((int(ai.attack)) * (random.randint(4, 9))) - ((int(playerattack)) * (random.randint(2, 3)))
        if int(player_dam_math) < 0:
          print("You should run! The " + ai.name + " is too powerfull!")
          quarter = input("Do you want to fight or run: \n" )
          if quarter.lower() == ('fight'):
            input("Press Enter to Continue")
            hand_to_hand_combat(combat_round, my_player, ai, battleground, playerlocation)
           
          elif quarter.lower() == ('run'):
            combat_state = 0
            player_move(quarter.lower(), combat_state)
                   
          else:
            print("Unknown command")
            print("The battle continues.\n")  
            hand_to_hand_combat(combat_round, my_player, ai, battleground, playerlocation)
        else:
          if int(ai_dam_math) < 0:
            print("No damage.")
          else:
            my_player.health -= abs(ai_dam_math)
            print("Points of damage taken: " + str(ai_dam_math) + "")

########################################################################################################


          ai.health -= abs(player_dam_math)
          if ai.health <= 0:
            combat_state = 0
            loot_state(ai, battleground)
          elif my_player.health <= 0:
            print('What a lovely youth, still so young and strong. Such a pity...Death shakes \n' +
'his head, lifts his scythe and cuts you down...Such a pity...\n\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0+0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-+0\n'+
'0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n'+
'0000000000000000000000000000000000000000000000000000000000000 000000000000 00000\n'+
'0|0000            00000000000000000    0000  00000000000000 000000000000000 00|0\n'+
'000000  000000000 0000000000000000000  0000  0000000000000000     000     000000\n'+
'0|0000  0000000000000000000000000000000 000  00000000000000000    000    00000|0\n'+
'000000  000000000    000000000 0  000000 00  000    0000000000000000000000000000\n'+
'0|0000  0  00000  00  00   000  000 00000   00  000  0000000  00000 00000  000|0\n'+
'000000  00000000 000000 000 00 00000000000  00 000000000000000 000   000 0000000\n'+
'0|0000  00000000 000000 000 00 00000000000  00 0000000000000000000000000000000|0\n'+
'000000  00000000      00  00 0 00000000000   0      00000000000         00000000\n'+
'0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n'+
'0+-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0+0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'\n\n\n\nYou go on ahead, we will wait right here...\n')
            sys.exit()
          else:
            mesg = random.randint(0,2)
            dam_mes = player_dam_mesg.pop(int(mesg))
            print("Points of damge you deal: " + str(player_dam_math) + "")
            print("When you " + str(dam_mes) + " with your " + playerweapon + ".")

########################################################################################################

            print("Your health: " + str(my_player.health) + "")
            print("" + ai.name + " health: " + str(ai.health) + "")
            print("Combat round: " + str(combat_round) + "")
            quarter = input("Do you want to fight or run: \n" )
            if quarter.lower() == ('fight'):
              input("Press Enter to Continue")
              hand_to_hand_combat(combat_round, my_player, ai, battleground, playerlocation)
           
            elif quarter.lower() == ('run'):
              combat_state = 0
              player_move(quarter.lower())
                   
            else:
              print("Unknown command")
              print("The battle continues.\n")  
              hand_to_hand_combat(combat_round, my_player, ai, battleground, playerlocation)
        
      else:
        combat_state = 0
        loot_state(ai, battleground)
    else:  
     
      print('\nWhat a lovely youth, still so young and strong. Such a pity...Death shakes \n' +
'his head, lifts his scythe and cuts you down...Such a pity...\n\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0+0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-+0\n'+
'0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n'+
'0000000000000000000000000000000000000000000000000000000000000 000000000000 00000\n'+
'0|0000            00000000000000000    0000  00000000000000 000000000000000 00|0\n'+
'000000  000000000 0000000000000000000  0000  0000000000000000     000     000000\n'+
'0|0000  0000000000000000000000000000000 000  00000000000000000    000    00000|0\n'+
'000000  000000000    000000000 0  000000 00  000    0000000000000000000000000000\n'+
'0|0000  0  00000  00  00   000  000 00000   00  000  0000000  00000 00000  000|0\n'+
'000000  00000000 000000 000 00 00000000000  00 000000000000000 000   000 0000000\n'+
'0|0000  00000000 000000 000 00 00000000000  00 0000000000000000000000000000000|0\n'+
'000000  00000000      00  00 0 00000000000   0      00000000000         00000000\n'+
'0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n'+
'0+-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0+0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'\n\n\n\nYou go on ahead, we will wait right here...\n')
      sys.exit()

  return

def loot_state(ai, battleground):
  print("Victory!\nThe " + ai.name +" has been defeated.")

#########################################################################################################
  t_int = random.randint(0,12)
  reward = ['pocketwatch\n','copper key\n','faded hat\n','old belt\n','wand\n','dirty rags\n','silver earring\n','screwdriver\n','empty candy tin\n','beautiful ring\n','wool socks\n','carved jade dragon\n','small gold coin\n']
#########################################################################################################

  loot = reward.pop(int(t_int))
  ai_death(ai, battleground, loot)

def ai_death(ai, battleground, loot):
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  backpack_len = file.readlines()
  length = len(backpack_len)
  file.close()
  if length > 15:
    print("Your backpack is full.")
    file = open('./Players/' + my_player.name + '/' + battleground + '.txt','r')
    location = file.readlines()
    file.close()
    file = open('./Players/' + my_player.name + '/' + battleground + '.txt','a+')
    file.write(loot)
    file.close()
    prompt()   
  else:
    print("For your effort you gained a " + loot + "")
    file = open('./Players/' + my_player.name + '/inventory.txt','a+')
    file.write(loot)
    file.close
    print("Your health: " + str(my_player.health) + "")
    ai.dead = True
    combat_state = 0
    combat_round = 0
    prompt()
combat_state = 0

#######################################################################################################
#                                                                                                     #
#                                               get item function                                     #
#######################################################################################################

######################################################
#        update player master list                   #                                              ###################################################### 
def move_bronze(new_item):
  file = open('./Players/' + my_player.name + '/treasuryList.txt','r')
  contents = file.read() 
  if new_item in contents:
    file.close()
    file = open('./Players/' + my_player.name + '/treasuryList.txt','r')
    lines = file.readlines()
    next_file = open('./Players/' + my_player.name + '/treasuryList.txt','w')
    for line in lines:
      if line != ('' + str(new_item) + '\n'):
        next_file.write(line)
        continue
      continue
    file.close()
    next_file.close() 
    add_bronze(new_item)
  else:
    print("Something maybe amiss with your file structure.\n")
    file.close()
    prompt()

######################################################
#        check pack + add item                       #                                              ######################################################
def add_bronze(new_item):
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  backpack_len = file.readlines()
  length = len(backpack_len)
  file.close()
  if length > 15:
    print("Your backpack is full.")
    prompt()   
  else:
    my_player.attack += 5
    print("You take the bronze sword from behind the curtain.\n")
    file = open('./Players/' + my_player.name + '/inventory.txt','a+')
    file.write('' + str(new_item) + '\n')
    file.close()
    prompt()

######################################################
#        check redundant item                        #                                              ######################################################
def get_bronze():
  new_item = ('bronze sword')
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  my_contents = file.read()
        
  if new_item.lower() in my_contents:
    file.close()
    print("You already have the " + str(new_item) +".\n")
    prompt()
  else:
    file.close()
    move_bronze(new_item)

#########################################################################################################
#########################################################################################################

#######################################################################################################
#                                                                                                     #
#                                                 search function                                     #
#######################################################################################################
def search_items():
  print("Searching...\n\nThe people who lived here saved almost everything. In the clutter loosely \norganized around their mattress they left everything from torn magazine covers \nto a toilet brush.\n")
  cmd = input("If there is something specific you need just type in now: \n")

  if cmd in ('nuts and bolts','comb','toilet brush','shoe horn','reading glasses','golfer pencil','rain jacket','makeup tin','jump rope'):

#########################################################################################################
#########################################################################################################

    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    backpack_len = file.readlines()
    length = len(backpack_len)
    file.close()
    if length > 15:
      print("You might have seen one, but your backpack is full.")
      prompt()   
    else:
      found_item(cmd)
  else:
    print("You don't find a " + str(cmd) + " in all the mess of things.\n")
    prompt()

def found_item(cmd):

#######################################################################################################
#                                                                                                     #
#                                        update master player item list                               #
#######################################################################################################

  file = open('./Players/' + my_player.name + '/treasuryList.txt','r')
  contents = file.read() 
  if cmd in contents:
    file.close()
    file = open('./Players/' + my_player.name + '/treasuryList.txt','r')
    lines = file.readlines()
    next_file = open('./Players/' + my_player.name + '/treasuryList.txt','w')
    for line in lines:
      if line != ('' + str(cmd) + '\n'):
        next_file.write(line)
        continue
      continue
    file.close()
    next_file.close() 
    add_found_item(cmd)
  else:
    print("Something maybe amiss with your file structure.\nDo you already have a " + str(cmd) + "?\n")
    file.close()
    prompt()

def add_found_item(cmd):
  print("What luck! You find a " + str(cmd) + "!\n")
  file = open('./Players/' + my_player.name + '/inventory.txt','a+')
  file.write('' + str(cmd) + '\n')
  file.close
  prompt()


#######################################################################################################
#                                                                                                     #
#                                                 multi item function                                #
#######################################################################################################
def get_junk():
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  backpack_len = file.readlines()
  length = len(backpack_len)
  file.close()
  if length > 15:
    print("Your backpack is full.")
    prompt()   
  else:

#########################################################################################################
#########################################################################################################
    junk = ('hat pin\n','locket\n','flashlight\n','mittens\n','emerald\n')
#########################################################################################################
#########################################################################################################

    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    my_stuff = file.readlines()
    file.close()
    file = open('./Players/' + my_player.name + '/inventory.txt','w+')
    file.writelines(my_stuff)
    file.writelines(junk)
    file.close
    prompt()

#########################################################################################################
#########################################################################################################

def try_green_key():
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  my_contents = file.read()
        
  if 'green key' in my_contents:
    file.close()
    print("You twist the key inside the lock. The door opens.\n")
    my_player.location = 'Singing_Crystals'
    print_location()
  else:
    print("This is not the correct key.\n")
    file.close
    prompt()

#########################################################################################################
#########################################################################################################

#######################################################################################################
#                                                                                                     #
#                                                 key getting function                                #
#######################################################################################################

#########################################################################################################
#########################################################################################################

def get_turquoise_key():
  
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  my_contents = file.read()

  if 'turquoise key' in my_contents:
    file.close()
    print("You already have this item.\n")
  else:
    file.close()
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    backpack_len = file.readlines()
    length = len(backpack_len)
    file.close()
    if length > 15:
      print("Your backpack is full.")
      prompt()   
    else:
      print("You get the Turquoise Key from the " + my_player.location + "")
      file = open('./Players/' + my_player.name + '/inventory.txt','a+')
      file.write('turquoise key\n')
      file.close()
      prompt()

#######################################################################################################
#                                                                                                     #
#                                                 necc. specific CMDS                                 #
#######################################################################################################


def show():
  playerlocation = my_player.location.lower()

  print("Showing...\n\nThe things you can get: ")
  with open('./Players/' + my_player.name + '/' +  str(playerlocation) + '.txt','r') as show_items:
    lines = show_items.read()
    print(lines)

    prompt()

def player_status(myAction):
  print("Name: " + my_player.name + "")
  print("Health: " + str(my_player.health) + "\n")
  print("You are wearing:\n")
  file = open('./Players/' + my_player.name + '/wearing.txt','r')
  garments = file.read()
  print("" + garments + "")
  file.close()

  print("And in your hands you have:")
  file = open('./Players/' + my_player.name + '/holding.txt','r')
  worts = file.read()
  print(worts)
  file.close()
  prompt()

#######################################################################################################
#                                                                                                     #
#                                                      basic commands                                 #
#######################################################################################################

def player_clear(myAction):
  os.system('clear')
  prompt()

def player_move(myAction):
  print('North - South - East - West - Up - Down')
  ask = "Choose a direction: "
  destination = input(ask)
  destinations = ['north', 'south', 'east', 'west','up','down']
  if destination in ['north']:
    destination = zonemap[my_player.location][NORTH]
    movement_handler(destination)
  elif destination in ['south']:
    destination = zonemap[my_player.location][SOUTH]
    movement_handler(destination)
  elif destination in ['east']:
    destination = zonemap[my_player.location][EAST]
    movement_handler(destination)
  elif destination in ['west']:
    destination = zonemap[my_player.location][WEST]
    movement_handler(destination)
  elif destination in ['up']:
    destination = zonemap[my_player.location][UP]
    movement_handler(destination)
  elif destination in ['down']:
    destination = zonemap[my_player.location][DOWN]
    movement_handler(destination)

#######################################################################################################
#      here is a hard coded element                                                                   #                                              
#                                       save game                                                     #
#######################################################################################################

def load_backpack():

  save_room = input("Save your current location?\nYes or No.\n")
  if save_room.lower() in 'no':
    file = open('./Players/' + my_player.name + '/startlocation.txt','w+')

    file.write('1')
    file.close()
    save_name()
    
  else:
    file = open('./Players/' + my_player.name + '/startlocation.txt','w+')
    file.write(my_player.location)
    file.close()
    save_name()

def save_name():
  file = open('./Lists/player_card.txt','r')
  players = file.read()
  if my_player.name not in players:
    file.close()
    file = open('./Lists/player_card.txt','a+')
    file.write('' + str(playername) + '\n')
    file.close
    close_all_files()
  else:
    close_all_files()

def close_all_files():
  sys.exit()

#######################################################################################################
#                                                                                                     #                                     delete   
#                                                                                                     #
#######################################################################################################

def end_game():
  playername = my_player.name
  file = open('./Lists/player_card.txt','r')
  players = file.readlines()
  remove_player = open('./Lists/player_card.txt','w+')
  for player in players:
    if player != str(playername):
      remove_player.write(player)
      continue
    continue
  file.close()
  remove_player.close()
  os.system("rm -r ./Players/" + str(playername))
  sys.exit()

#######################################################################################################
#                                                                                                     #
#                                                      prompt                                         #
#######################################################################################################

def prompt():
  print('' + zonemap[my_player.location][DESCRIPTION] + ' ')
#  print('show more - move - look - options - status - quit')
  print('show more - move - look - options - status - quit')
  global playerlocation
  playerlocation = my_player.location
  global playername
  playername = my_player.name.lower()
  global action
  action = input("Command: ")
  actions = ['quit','look','move','options','status','show more']
  if action.lower() not in actions:
    print('Command unrecognized.\n')
    prompt()
####################################DOUBLE#CHECK#QUIT##############################################
  elif action.lower() == ("quit"):
    quit_logo = input("Save Game For You?\nYes or No: \n")
    if quit_logo.lower() in ('yes'):
      load_backpack()
    else:
      print("Warning: Any reply other than 'yes' will delete your player completely!!!\n")
      secure_quit = input("Yes to save this player and progress!!!\n")
      if secure_quit.lower() in ('yes'):
        load_backpack()
      else:
        end_game()
###################################################################################################
  elif action.lower() in ['move']:
    player_move(action.lower())
    return
  elif action.lower() in ['look']:
    player_look()
  elif action.lower() in ['options']:
    player_options(action.lower())
    return
  elif action.lower() in ['status']:
    player_status(action.lower())
    return
  elif action.lower() in ['show more']:
    show()

#######################################################################################################
#                                                                                                     #
#                                                 generate necc txt files                             #
#######################################################################################################

def inventory_stripe(playername):
  file = open('./Players/' + playername + '/inventory.txt','w+')
  file.close()

def treasury_stripe(playername):
  file = open('./Lists/treasuryList.txt','r')
  basics = file.readlines()
  inv = open('./Players/' + playername + '/treasuryList.txt','w+')
  for basic in basics:
    inv.write(basic)
    continue
  file.close()
  inv.close()

def holding_stripe(playername):
  file = open('./Players/' + playername + '/holding.txt','w+')
  file.close()

def wearing_stripe(playername):

  file = open('./Lists/basic_inventory.txt','r')
  basics = file.readlines()
  inv = open('./Players/' + playername + '/wearing.txt','w+')
  for basic in basics:
    inv.write(basic)
    continue
  file.close()
  inv.close()
 
def clothing_stripe():
  file = open('./Lists/clothing.txt','r')
  file.close()

def weaponOrTool_stripe():
  file = open('./Lists/weaponOrTool.txt','r')
  file.close()

def treasure_stripe():
  file = open('./Lists/treasure.txt','r')
  file.close()

def player_files(playername):
  file = open('./Players/' + playername + '/wearing.txt','r')
  file.close()

def new_holding(playername):
  file = open('./Players/' + playername + '/holding.txt','r')
  file.close()

def new_inv(playername):
  file = open('./Players/' + playername + '/inventory.txt','r')
  file.close()

def new_treas(playername):
  file = open('./Players/' + playername + '/treasuryList.txt','r')
  file.close()

#######################################################################################################
#                                                                                                     #
#                                                 character CRUD                                      #
#######################################################################################################

def append_wear(clothing_c, playerlocation):
  file = open('./Players/' + my_player.name + '/wearing.txt','r')
  isWearing = file.read()
  
  if clothing_c in isWearing:
    print("You already are wearing your " + clothing_c + "") 
    file.close()
    prompt()
    
  else:
    file.close()
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    items = file.readlines()
    line_write_file = open('./Players/' + my_player.name + '/inventory.txt','w')
    for item in items:
      if item != ('' + str(clothing_c) + '\n'):
        line_write_file.write(item)
        continue
      continue
    file.close()
    line_write_file.close()
    file = open('./Players/' + my_player.name + '/wearing.txt','a+')
    file.write('' + str(clothing_c) + '\n')
    file.close()
    print("You wear your " + clothing_c + '')
    prompt()

def append_WorT(weapon_or_tool_c, playerlocation):
  file = open('./Players/' + my_player.name + '/holding.txt','r')
  isHolding = file.readlines()
  
  length = len(isHolding)
  if weapon_or_tool_c in isHolding:
    print("" + weapon_or_tool_c + " is already in your hands.")
    file.close()
    return
  elif length > 1:
    print("You only have two hands.")
    prompt()
    
  else:
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    items = file.readlines()
    line_write_file = open('./Players/' + my_player.name + '/inventory.txt','w')
    for item in items:
      if item != ('' + str(weapon_or_tool_c) + '\n'):
        line_write_file.write(item)
        continue
      continue
    file.close()
    line_write_file.close()
    file = open('./Players/' + my_player.name + '/holding.txt','a+')
    file.write('' + str(weapon_or_tool_c) + '\n')
    file.close()
    print("Your " + weapon_or_tool_c + " is in your hands.")
    prompt()

def take_item(want, playerlocation):
  playerlocation = my_player.location.lower()
  file = open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt','r')
  contents = file.read()
  
  if want in contents:
    file.close()
    file = open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt','r')
    lines = file.readlines()

    next_file = open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt','w')

    for line in lines:
      if line != ('' + str(want) + '\n'):
        next_file.write(line)
        continue
      continue
    file.close()
    next_file.close()
    
    append_inventory(want, playerlocation)
  else:
    file.close()
    prompt()  
  
def append_inventory(want, playerlocation):
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  backpack_len = file.readlines()
  length = len(backpack_len)
  file.close()
  if length > 15:
    print("Your backpack is full.")
    file = open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt','r')
    location = file.readlines()
    file.close()
    file = open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt','a+')
    file.write(want)
    file.close()
    prompt()   
  else:
    file = open('./Players/' + my_player.name + '/inventory.txt','a+')
    file.write('' + str(want) + '\n')
    file.close()
    prompt()

def update_room_contents(drop_item, playerlocation):

    with open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt') as file:
      l = list(file)
      with open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt','w+') as output:
        output.write(str('' + drop_item + '\n'))
        for line in l:
        
          output.write(line)
          continue
          
    prompt()

def drop_wearing(playerlocation, wearing_contents):

  drop_item = input("Choose item: \n")
  if drop_item in wearing_contents:
    file = open('./Players/' + my_player.name + '/wearing.txt','r')
    w_lines = file.readlines()
    
    next_file = open('./Players/' + my_player.name + '/wearing.txt','w')

    for w_line in w_lines:
      if w_line != ('' + str(dropr_item) + '\n'):
        next_file.write(w_line)
        continue         
      continue
    
    file.close()
    next_file.close()
    print("You drop your " + str(drop_item) + " in the " + str(playerlocation) + "")
    update_room_contents(drop_item, playerlocation)
  else:
    prompt()

def drop_holding(playerlocation, holding_contents): 

  drop_item = input("Choose item: \n")
  if drop_item in holding_contents:
    
    file = open('./Players/' + my_player.name + '/holding.txt','r')
    h_lines = file.readlines()
    
    next_file = open('./Players/' + my_player.name + '/holding.txt','w')

    for h_line in h_lines:
      if h_line != ('' + str(drop_item) + '\n'):
        next_file.write(h_line)
        continue
      continue
    
    file.close()
    next_file.close()
    print("You drop your " + str(drop_item) + " in the " + str(playerlocation) + "")
    update_room_contents(drop_item, playerlocation)
  else:
    prompt()

def drop_backpack(playerlocation, inventory_contents):
  drop_item = input("Choose item: ")

  if drop_item.lower() not in inventory_contents:
    print("You don't have one of those.\n")
    prompt()
        
  elif drop_item.lower() in inventory_contents:

    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    d_lines = file.readlines()
      
    next_file = open('./Players/' + my_player.name + '/inventory.txt','w')

    for d_line in d_lines:
      if d_line != ('' + str(drop_item) + '\n'):
        next_file.write(d_line)
        continue
      continue
    file.close()
    next_file.close()

    print("You drop your " + str(drop_item) + " in the " + str(playerlocation) + "")
    update_room_contents(drop_item, playerlocation)
  else:
    file.close()
    print("What is that?")
    prompt()

def inventory_commands(myDecisionX):
  playerlocation = my_player.location.lower()
  print('\nget - wear - hold - drop - update - go back')
  global inventX
  inventX = input("Inventory Command: ")
  if inventX.lower() not in ['get', 'wear', 'hold', 'drop','update','go back']:
    print("Unknown command. ")
    prompt()
  elif inventX.lower() == ('go back'):
    os.system('clear')
    prompt()
  elif inventX.lower() == 'get':
    file = open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt', 'r')
    contents = file.read()
    print(contents)
      
    global want
    want = input("What do you want to get: " )
    if want.lower() == ('go back'):
      file.close() 
      os.system('clear')
      prompt()

    elif want.lower() not in contents:
      print("Where do you see that?.\n")
      file.close()
      prompt()

    elif want.lower() in contents:
      file.close()
      file = open('./Players/' + my_player.name + '/inventory.txt','r')
      my_contents = file.read()
        
      if want.lower() in my_contents:
        file.close()
        print("You already have one of these.\n")
        prompt()
      else:
        print("You take the " + want + " from the " + playerlocation.lower() + "")
        file.close()
        take_item(want, playerlocation)
    else:
        print("This " + str (want) + " you want so bad might not exist\n")
        file.close()
        prompt()

  elif inventX.lower() == 'wear':
    playerlocation = my_player.location.lower()
    print('\n')
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    contents = file.read()
    print(contents)

    global clothing_c
    clothing_c = input("Choose item: ")
    if clothing_c.lower() == ('go back'):
      file.close()
      os.system('clear')
      prompt()
    elif clothing_c.lower() not in contents:
      print("You don't have one of those.\n")
      file.close()
      prompt()
    else:
      file.close()
      file = open('./Lists/clothing.txt','r')
      isGarment = file.read()

      if clothing_c in isGarment:
        file.close()
        append_wear(clothing_c, playerlocation)
          
      else:
        print("That is not something you can wear.")
        file.close()
        prompt()
          
  elif inventX.lower() == 'hold':
    playerlocation = my_player.location.lower()
    print('\n')
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    contents = file.read()
    print(contents)
      
    global tool_or_weapon_c
    tool_or_weapon_c = input("Choose item: ")
    if tool_or_weapon_c.lower() == ('go back'):
      file.close()
      os.system('clear')
      prompt()

    elif tool_or_weapon_c.lower() not in contents:
      print("You don't have one of those.\n")
      file.close()
      prompt()
        
    else:
      file.close()
      file = open('./Lists/weaponOrTool.txt','r')
      isWorT = file.read()
        
      if tool_or_weapon_c.lower() in isWorT:
        file.close()
        append_WorT(tool_or_weapon_c, playerlocation)
          
      else:
        file.close()
        print("That is not a hand held implement.")
        prompt()

  elif inventX.lower() == 'drop':
    playerlocation = my_player.location.lower()
    print('In your hands:')
    file = open('./Players/' + my_player.name + '/holding.txt','r')
    holding_contents = file.read()
    print(holding_contents)
    file.close()
    print('You are wearing:')
    file = open('./Players/' + my_player.name + '/wearing.txt','r')
    wearing_contents = file.read()
    print(wearing_contents)
    file.close()
    print('In your backpack:')
    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    inventory_contents = file.read()
    print(inventory_contents)
    file.close()
    global drop_item
    choice = input("Select 'backpack', 'holding', or 'wearing': ")
    if choice.lower() == ('backpack'):
      drop_backpack(playerlocation, inventory_contents)
    elif choice.lower() == ('holding'):
      drop_holding(playerlocation, holding_contents)
    elif choice.lower() == ('wearing'):
      drop_wearing(playerlocation, wearing_contents)
    else:
      os.system('clear')
      prompt()

  elif inventX.lower() == 'update':
    os.system('clear')
    print("Updating inventory...\n")
    my_player.name = my_player.name
    inv_update(playername)

def inv_update(playername):

  with open('./Players/' + my_player.name + '/inventory.txt') as file:
    l = list(file)
  with open('./Players/' + my_player.name + '/inventory.txt','w+') as output:
    for line in l:
      output.write(line)
      continue
  prompt()

def player_options(myAction):
  os.system('clear')
  print('inventory - inventory commands - go back')
  opt = "Choose an option: "
  global decisionX
  decisionX = input(opt)

  if decisionX.lower() not in ['inventory', 'inventory commands','go back']:
    print("Unknown command. ")
    prompt()
  elif decisionX.lower() == ('go back'):
    os.system('clear')
    prompt()
  elif decisionX.lower() == ('inventory'):
    print("You have the following in your inventory...\n")

    with open('./Players/' + my_player.name + '/inventory.txt') as file:
      l = list(file)
      for line in l:
        print(line)
        continue
      with open('./Players/' + my_player.name + '/inventory.txt','w+') as output:
        for line in l:
        
          output.write(line)
          continue
    prompt()

  else: 
    decisionX.lower() == ('inventory commands')
    inventory_commands(decisionX)

#######################################################################################################
#                                                                                                     #
#                                                 set up and main                                     #
#######################################################################################################

def main_game_loop():
  while my_player.game_over is False:
    prompt()

def setup_game():

  question = "\nGreetings adventurer. What's your name?\n"
  for character in question:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)
  playername = input("Your Name: ")

  my_player.name = playername

  welcome = "Okay, " + my_player.name + " let's begin. You need to know a few things.\n"
  for character in welcome:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.03)

  help = "### Verbs are available and certain language processing. The basic CMDS \n" 
  help1 = "### are: look, get, drop, hold, show more, challenges, and move. You \n"
  help2 = "### have a certain amount of Health, check this with: status, and you \n"
  help3 = "### can only explore Underkingdom for a certain amount of time. Use: \n"
  help4 = "### clock to make sure you do not get trapped!\n\n"
  help5 = "### If you do get stuck, you can quit and start again at the beginning. \n"
  help6 = "### And remember it is just a game!\n\n"
  for character in help:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)
  for character in help1:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)
  for character in help2:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)
  for character in help3:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)
  for character in help4:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)
  for character in help5:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)
  for character in help6:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.04)

  goodluck = "\n\n\nOkay, " + my_player.name + " you will be you and the clock starts ticking now!!!\n"
  for character in goodluck:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.08) # was time.sleep(0.08)
  os.system('clear')
  os.system("mkdir ./Players/" + my_player.name)
  os.system("cd ./Players/" + my_player.name)
  os.system("touch __init__.py")
  os.system("cd ..")
  os.system("cp -r ./Rooms/* ./Players/" + my_player.name)
  inventory_stripe(playername)
  treasury_stripe(playername)
  holding_stripe(playername)
  wearing_stripe(playername)
  player_files(playername)
  new_holding(playername)
  new_inv(playername)
  new_treas(playername)
  run_game(playername)

def run_game(playername):
  my_player.name = my_player.name
  treasure_stripe()
  weaponOrTool_stripe()
  clothing_stripe()

  welcome = "\n\n\nWelcome to the Under Kingdom\n"
  for character in welcome:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.1)

#######################################################################################################
#                                                                                                     #
#                                                desc first room                                      #
#######################################################################################################

  print('\n\nTerrible Luck!\nYou fell through a crack in the ceiling above. It is a good thing you never go anywhere these days without your adventuring kit!\n\n')
  player.location = '1'
  main_game_loop()

title_screen()
