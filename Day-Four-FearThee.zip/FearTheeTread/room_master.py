
import textwrap
import time
import random
import math
import csv
##############################################################################
#  SWORD + FORTUNE + GOLD = YOU WIN PLAY THE NEXT MODULE SOON!               #
##############################################################################
#
ZONEMAP = []
ZONENAME= ''
DESCRIPTION = 'description'
EXAMINATION = 'examine'
SOLVED = False
NORTH = 'north'
SOUTH = 'south'
EAST = 'east'
WEST = 'west'
UP = 'up'
DOWN = 'down'
EXIT = 'north'
DEATH = 'death'
ESCAPE = 'escape'
NO_MOVE = 'no_move'
ITEM = 'item'


solved_places = {'':False, '':False }

zonemap = {

  '1': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'1. A crack in the ceiling above the middle of the north wall allows a trickle of water to flow down to the floor. The water pools near the base of the wall, and a rivulet runs along the wall an out into the hall. The water smells fresh.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '2',
	EAST: '',
	WEST: '7',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '2': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'2. Thick cobwebs fill the corners of the room, and wisps of webbing hang from the ceiling and waver in a wind you can barely feel. One corner of the ceiling has a particularly large clot of webbing within which a goblin\'s bones are tangled.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '1',
	SOUTH: '4',
	EAST: '3',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '3': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'3. Tapestries decorate the walls of this room. Although they may once have been brilliant in hue, they now hang in graying tatters. Despite the damage of time and neglect, you can perceive once-grand images of wizards\' towers, magical beasts, and symbols of spellcasting. The tapestry that is in the best condition bulges out weirdly, as though someone stands behind it (an armless statue of a female human spellcaster).\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: '2',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '4': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'4. Rats inside the room shriek when they hear the door open, then they run in all directions from a putrid corpse lying in the center of the floor. As these creatures crowd around the edges of the room, seeking to crawl through a hole in one corner, they fight one another. The stinking corpse in the middle of the room looks human, but the damage both time and the rats have wrought are enough to make determining its race by appearance an extremely difficult task at best.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '2',
	SOUTH: '5',
	EAST: '',
	WEST: '14',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '5': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'5. Neither light nor darkvision can penetrate the gloom in this chamber. An unnatural shade fills it, and the room\'s farthest reaches are barely visible. Near the room\'s center, you can just barely perceive a lump about the size of a human lying on the floor. (It might be a dead body, a pile of rags, or a sleeping monster that can take advantage of the room\s darkness.)\n\n'+

#DM Note: The darkness can come from a deeper darkness spell effect.

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '4',
	SOUTH: '',
	EAST: '',
	WEST: '8',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '6': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'6. Burning torches in iron sconces line the walls of this room, lighting it brilliantly. At the room\'s center lies a squat stone altar, its top covered in recently spilled blood. A channel in the altar funnels the blood down its side to the floor where it fills grooves in the floor that trace some kind of pattern or symbol around the altar. Unfortunately, you can\'t tell what it is from your vantage point.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: '10',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '7': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'7. A liquid-filled pit extends to every wall of this chamber. The liquid lies about 10 feet below your feet and is so murky that you can\'t see its bottom. The room smells sour. A rope bridge extends from your door to the room\'s other exit.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '10',
	SOUTH: '',
	EAST: '1',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '8': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'8. Fire crackles and pops in a small cooking fire set in the center of the room. The smoke from a burning rat on a spit curls up through a hole in the ceiling. Around the fire lie several fur blankets and a bag. It looks like someone camped here until not long ago, but then left in a hurry.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '9',
	EAST: '5',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '9': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'9. A flurry of bats suddenly flaps through the doorway, their screeching barely audible as they careen past your heads. They flap past you into the rooms and halls beyond. The room from which they came seems barren at first glance.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '8',
	SOUTH: '16',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '10': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'10. Rusting spikes line the walls and ceiling of this chamber. The dusty floor shows no sign that the walls move over it, but you can see the skeleton of some humanoid impaled on some wall spikes nearby.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '7',
	EAST: '6',
	WEST: '11',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '11': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'11. You open the door, and the reek of garbage assaults your nose. Looking inside, you see a pile of refuse and offal that nearly reaches the ceiling. In the ceiling above it is a small hole that is roughly as wide as two human hands. No doubt some city dweller high above disposes of his rubbish without ever thinking about where it goes.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '12',
	EAST: '10',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '12': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'12. You open the door, and the room comes alive with light and music. A sourceless, warm glow suffuses the chamber, and a harp you cannot see plays soothing sounds. Unfortunately, the rest of the chamber isn\'t so inviting. The floor is strewn with the smashed remains of rotting furniture. It looks like the room once held a bed, a desk, a chest, and a chair.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '11',
	SOUTH: '13',
	EAST: '',
	WEST: '22',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '13': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'13. A skeleton dressed in moth-eaten garb lies before a large open chest in the rear of this chamber. The chest is empty, but you note two needles projecting from the now-open lock. Dust coats something sticky on the needles\' points.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '12',
	SOUTH: '',
	EAST: '',
	WEST: '23',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '14': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'14. Rounded green stones set in the floor form a snake\'s head that points in the direction of the doorway you stand in. The body of the snake flows back and toward the wall to go round about the room in ever smaller circles, creating a spiral pattern on the floor. Similar green-stone snakes wend along the walls, seemingly at random heights, and their long bodies make wave shapes.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '15',
	EAST: '4',
	WEST: '24',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '15': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'15. The manacles set into the walls of this room give you the distinct impression that it was used as a prison and torture chamber, although you can see no evidence of torture devices. One particularly large set of manacles -- big enough for an ogre -- have been broken open.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '14',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '16': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'16. You gaze into the room and hundreds of skulls gaze coldly back at you. They\'re set in niches in the walls in a checkerboard pattern, each skull bearing a half-melted candle on its head. The grinning bones stare vacantly into the room, which otherwise seems empty.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '9',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '17': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'17. Unlike the flagstone common throughout the dungeon, this room is walled and floored with black marble veined with white. The ceiling is similarly marbled, but the thick pillars that hold it up are white. A brown stain drips down one side of a nearby pillar.\n\n'+

#DM Note: The stain could be old blood.

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: '26',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '18': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'18. A huge iron cage lies on its side in this room, and its gate rests open on the floor. A broken chain lies under the door, and the cage is on a rotting corpse that looks to be a hobgoblin. Another corpse lies a short distance away from the cage. It lacks a head.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '17',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '19': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'19. This room is a tomb. Stone sarcophagi stand in five rows of three, each carved with the visage of a warrior lying in state. In their center, one sarcophagus stands taller than the rest. Held up by six squat pillars, its stone bears the carving of a beautiful woman who seems more asleep than dead. The carving of the warriors is skillful but seems perfunctory compared to the love a sculptor must have lavished upon the lifelike carving of the woman.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '20',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '20': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'20. A dim bluish light suffuses this chamber, its source obvious at a glance. Blue-glowing lichen and violet-glowing moss cling to the ceiling and spread across the floor. It even creeps down and up each wall, as if the colonies on the floor and ceiling are growing to meet each other. Their source seems to be a glowing, narrow crack in the ceiling, the extent of which you cannot gauge from your position. The air in the room smells fresh and damp.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '19',
	SOUTH: '21',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '21': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'21. You open the door to confront a room of odd pillars. Water rushes down from several holes in the ceiling, and each hole is roughly a foot wide. The water pours in columns that fall through similar holes in the floor, flowing down to some unknown depth. Each of the eight pillars of water drops as much liquid as a stream in winter thaw. The floor is damp and looks slippery.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '20',
	SOUTH: '22',
	EAST: '',
	WEST: '28',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '22': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'22. This room smells strange, no doubt due to the weird sheets of black slime that drip from cracks in the ceiling and spread across the floor. The slime seeps from the shattered stone of the ceiling at a snails crawl, forming a mess of dangling walls of gook. As you watch, a bit of the stuff separates from a sheet and drops to the ground with a wet plop.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '21',
	SOUTH: '23',
	EAST: '12',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '23': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'23. This room is hung with hundreds of dusty tapestries. All show signs of wear: moth holes, scorch marks, dark stains, and the damage of years of neglect. They hang on all the walls and hang from the ceiling to brush against the floor, blocking your view of the rest of the room.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '22',
	SOUTH: '',
	EAST: '13',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '24': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'24. You catch a whiff of the unmistakable metallic tang of blood as you open the door. The floor is covered with it, and splashes of blood spatter the walls. Some drops even reach the ceiling. It looks fresh, but you don\'t see any bodies or footprints leaving the chamber.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '25',
	EAST: '14',
	WEST: '31',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '25': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'25. Three low, oblong piles of rubble lie near the center of this small room. Each has a weapon jutting upright from one end -- a longsword, a spear, and a quarterstaff. The piles resemble cairns used to bury dead adventurers.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '24',
	SOUTH: '26',
	EAST: '',
	WEST: '32',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '26': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'26. Huge rusted metal blades jut out of cracks in the walls, and rusting spikes project down from the ceiling almost to the floor. This room may have once been trapped heavily, but someone triggered them, apparently without getting killed. The traps were never reset and now seem rusted in place.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '25',
	SOUTH: '',
	EAST: '17',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '27': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'27. Several round pits lie in the floor of the room before you. Spaced roughly equally apart, each is about 15 feet in diameter and appears about 20 feet deep. A lattice of thick iron bars covers the top of each pit, and each lattice has a door of iron bars that can be lifted open. The pits smell of sweat and offal, but the room seems unoccupied.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '28',
	EAST: '',
	WEST: '35',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '28': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'28. Many doors fill the room ahead. Doors of varied shape, size, and design are set in every wall and even the ceiling and floor. Barely a hand\'s width lies between one door and the next. All the doors but the one you entered by are shut, and many have obvious locks.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '27',
	SOUTH: '',
	EAST: '21',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '29': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'29. A strange ceiling is the focal point of the room before you. It\'s honeycombed with hundreds of holes about as wide as your head. They seem to penetrate the ceiling to some height beyond a couple feet, but you can\'t be sure from your vantage point.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '28',
	SOUTH: '30',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '30': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'30. This chamber was clearly smaller at one time, but something knocked down the wall that separated it from an adjacent room. Looking into that space, you see signs of another wall knocked over. It doesn\'t appear that anyone made an effort to clean up the rubble, but some paths through see more usage than others.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '29',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '31': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'31. A chill wind blows against you as you open the door. Beyond it, you see that the floor and ceiling are nothing but iron grates. Above and below the grates the walls extend up and down with no true ceiling or floor within your range of vision. It\'s as though the chamber is a bridge through the shaft of a great well. Standing on the edge of this shaft, you feel a chill wind pass down it and over your shoulder into the hall beyond.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '32',
	EAST: '',
	WEST: '39',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '32': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'32. This room is shattered. A huge crevasse shears the chamber in half, and the ground and ceilings are tilted away from it. It\'s as though the room was gripped in two enormous hands and broken like a loaf of bread. Someone has torn a tall stone door from its hinges somewhere else in the dungeon and used it to bridge the 15-foot gap of the chasm between the two sides of the room. Whatever did that must have possessed tremendous strength because the door is huge, and the enormous hinges look bent and mangled.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '31',
	SOUTH: '33',
	EAST: '25',
	WEST: '40',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '33': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'33. A pit yawns open before you just on the other side of the door\'s threshold. The entire floor of the room has fallen into a second room beneath it. Across the way you can spy a door in the wall now 15 feet off the rubble-strewn floor, and near the center of the room stands a thick column of mortared stone that appears to hold the spiral staircase that leads down to what was the lower level.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '32',
	SOUTH: '34',
	EAST: '',
	WEST: '51',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '34': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'34. As the door opens, it scrapes up frost from a floor covered in ice. The room before you looks like an ice cave. A tunnel wends its way through solid ice, and huge icicles and pillars of frozen water block your vision of its farthest reaches.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '33',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '35': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'35. A 30-foot-tall demonic idol dominates this room of black stone. The potbellied statue is made of red stone, and its grinning face holds what looks to be two large rubies in place of eyes. A fire burns merrily in a wide brazier the idol holds in its lap.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '36',
	EAST: '',
	WEST: '27',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '36': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'36. Several exits lead from this room, but only one is within the mouth of a man. The door opposite you stands within an intricate stone carving of a man\'s wide-open mouth. The man\'s nose and eyes loom over the door while his sculpted hair splays out across the wall on either side.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '35',
	SOUTH: '37',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '37': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'37. The door creaks open, which somewhat overshadows the sound of bubbling liquid. Before you is a room about which alchemists dream. Three tables bend beneath a clutter of bottles of liquid and connected glass piping. Several bookshelves stand nearby stuffed to overfilling with a jumble of books, jars, bottles, bags, and boxes. The alchemist who set this all up doesn\'t seem to be present, but a beaker of green fluid boils over a burner on one of the tables.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '36',
	SOUTH: '38',
	EAST: '',
	WEST: '42',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '38': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'38. The scent of earthy decay assaults your nose upon peering through the open door to this room. Smashed bookcases and their sundered contents litter the floor. Paper rots in mold-spotted heaps, and shattered wood grows white fungus.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '37',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '39': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'39. Several white marble busts that rest on white pillars dominate this room. Most appear to be male or female humans of middle age, but one clearly bears small horns projecting from its forehead and another is spread across the floor in a thousand pieces, leaving one pillar empty.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '40',
	EAST: '31',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '40': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'40. A dozen statues stand or kneel in this room, and each one lacks a head and stands in a posture of action or defense. All are garbed for battle. It\'s difficult to tell for sure without their heads, but two appear to be dwarves, one might be an elf, six appear human, and the rest look like they might be orcs.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '39',
	SOUTH: '51',
	EAST: '32',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '41': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'41. A rusted portcullis stands just beyond the door. Looking into the room, you see three other exits, similarly blocked by portcullises. Four skeletons dressed in aged clothing and rusting armor lie on the floor in the room against the walls. They seem in poses of repose rather than violence.\n\n'+

#DM Note: A massive extensive Dead-End Run.

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '43',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '42': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'42. This tiny room holds a curious array of machinery. Winches and levers project from every wall, and chains with handles dangle from the ceiling. On a nearby wall, you note a pictogram of what looks like a scythe on a chain.\n\n'+

#DM Note: This room may be a control center for traps elsewhere in the dungeon.

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '37',
	WEST: '45',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '43': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'43. This narrow room at first appears to be a dead-end corridor, but then you note several metal plates on the walls set at about eye height. Looking more closely, you see that one of these plates is slid aside to reveal a peephole.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '44',
	SOUTH: '41',
	EAST: '',
	WEST: '48',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '44': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'44. You open the door to a scene of carnage. Two male humans, a male elf, and a female dwarf lie in drying pools of their blood. It seems that they might once have been wearing armor, except for the elf, who remains dressed in a blue robe. Clearly they lost some battle and victors stripped them of their valuables.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '43',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
  '45': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'45. This chamber served as an armory for some group of creatures. Armor and weapon racks line the walls and rusty and broken weapons litter the floor. It hasn\'t been used in a long time, and all the useful weapons have been taken but for a single sword. Unlike the other weapons in the room, this one gleams untarnished in the light.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '46',
	EAST: '42',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },

  '46': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'46. The door in front of you seems to be stuck. \n\n'+

#DM Note: If the PCs yank it open, it comes open. Read the following: A furious rumble resounds in the area as stones come clattering through the doorway, along with a thick cloud of rock dust. The room beyond is filled with rubble.

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '45',
	SOUTH: '',
	EAST: '',
	WEST: '49',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },

 '47': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'47. There\'s a hiss as you open this door, and you smell a sour odor, like something rotten or fermented. Inside you see a small room lined with dusty shelves, crates, and barrels. It looks like someone once used this place as a larder, but it has been a long time since anyone came to retrieve food from it.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '48',
	EAST: '',
	WEST: '50',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '48': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'48. A horrendous, overwhelming stench wafts from the room before you. Small cages containing small animals and large insects line the walls. Some of the creatures look sickly and alive but most are clearly dead. Their rotting corpses and the unclean cages no doubt result in the zoo\'s foul odor. A cat mews weakly from its cage, but the other creatures just silently shrink back into their filthy prisons.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '47',
	SOUTH: '',
	EAST: '43',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '49': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'49. A cluster of low crates surrounds a barrel in the center of this chamber. Atop the barrel lies a stack of copper coins and two stacks of cards, one face up. Meanwhile, atop each crate rests a fan of five face-down playing cards. A thin layer of dust covers everything. Clearly someone meant to return to their game of cards.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '50',
	EAST: '46',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '50': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'50. This chamber of well-laid stones holds a wide bas-relief of a pastoral scene. In it you see a mountain like Mount Waterdeep, except that Castle Waterdeep and the city are missing. Instead, a small fishing village is a short way from a walled complex with several tall towers.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '49',
	SOUTH: '',
	EAST: '47',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '51': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'51. A stone throne stands on a foot-high circular dais in the center of this cold chamber. The throne and dais bear the simple adornments of patterns of crossed lines -- a pattern also employed around each door to the room.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '33',
	WEST: '',
        UP: '',
        DOWN: '52',
        ITEM: '\n',
  },
 '52': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'52. A wall that holds a seat with a hole in it is in this chamber. It\'s a privy! The noisome stench from the hole leads you to believe that the privy sees regular use.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '57',
	SOUTH: '',
	EAST: '54',
	WEST: '',
        UP: '51',
        DOWN: '',
        ITEM: '\n',
  },
 '53': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'53. The burble of water reaches your ears after you open the door to this room. You see the source of the noise in the far wall: a large fountain artfully carved to look like a seashell with the figure of a seacat spewing clear water into its basin.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '55',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '54': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'54. This room holds six dry circular basins large enough to hold a man and a dry fountain at its center. All possess chipped carvings of merfolk and other sea creatures. It looks like this room once served some group of people as a bath.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: '52',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '55': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'55. A glow escapes this room through its open doorways. The masonry between every stone emanates an unnatural orange radiance. Glancing quickly about the room, you note that each stone bears the carving of someone\'s name.\n\n'+

#DM Note: Consider putting the name of one of your party\'s characters on the wall.

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '61',
	SOUTH: '53',
	EAST: '90',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '56': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'56. A huge stewpot hangs from a thick iron tripod over a crackling fire in the center of this chamber. A hole in the ceiling allows some of the smoke from the fire to escape, but much of it expands across the ceiling and rolls down to fill the room in a dark fog. Other details are difficult to make out, but some creature must be nearby, because it smells like a good soup is cooking.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: '57',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '57': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'57. You\'ve opened the door to a torture chamber. Several devices of degradation, pain, and death stand about the room, all of them showing signs of regular use. The wood of the rack is worn smooth by struggling bodies, and the iron maiden appears to be occupied by a corpse.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '62',
	SOUTH: '52',
	EAST: '56',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '58': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'58. This short hall leads to another door. On either side of the hall, niches are set into the wall within which stand clay urns. One of the urns has been shattered, and its contents have spilled onto its shelf and the floor. Amid the ash it held, you see blackened chunks of something that might be bone.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '63',
	SOUTH: '',
	EAST: '',
	WEST: '59',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '59': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'59. Corpses and pieces of corpses hang from hooks that dangle from chains attached to thick iron rings. Most appear humanoid but a few of the body parts appear more monstrous. You don\'t see any heads, hands, or feet -- all seem to have been chopped or torn off. Neither do you see any guts in the horrible array, but several thick leather sacks hang from hooks in the walls, and they are suspiciously wet and the leather looks extremely taut -- as if it\' under great strain.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '58',
	WEST: '69',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '60': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'60. This small chamber seems divided into three parts. The first has several hooks on the walls from which hang dusty robes. An open curtain separates that space from the next, which has a dry basin set in the floor. Beyond that lies another parted curtain behind which you can see several straw mats in a semicircle pointing toward a statue of a dog-headed man.\n\n'+

#DM Note: The first part of the room may have been used for changing and cleaning feet before entering the room with the statue.

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '59',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '61': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'61. When looking into this chamber, you\'re confronted by a thousand reflections of yourself looking back. Mirrored walls set at different angles fill the room. A path seems to wind through the mirrors, although you can\'t tell where it leads.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '55',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '62': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'62. A large forge squats against the far wall of this room, and coals glow dimly inside. Before the forge stands a wide block of iron with a heavy-looking hammer lying atop it, no doubt for use in pounding out shapes in hot metal. Other forge tools hang in racks nearby, and a barrel of water and bellows rest on the floor nearby.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '57',
	EAST: '',
	WEST: '63',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '63': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'63. This chamber is clearly a prison. Small barred cells line the walls, leaving a 15-foot-wide pathway for a guard to walk. Channels run down either side of the path next to the cages, probably to allow the prisoners\' waste to flow through the grates on the other side of the room. The cells appear empty but your vantage point doesn\'t allow you to see the full extent of them all.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '66',
	SOUTH: '58',
	EAST: '62',
	WEST: '64',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '64': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'64. You push open the stone door to this room and note that the only other exit is a door made of wood. It and the table shoved against it are warped and swollen. Indeed, the table only barely deserves that description. Its surface is rippled into waves and one leg doesn\'t even touch the floor. The door shows signs of someone trying to chop through from the other side, but it looks like they gave up.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '63',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '65': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'65. This otherwise bare room has one distinguishing feature. The stone around one of the other doors has been pulled over its edges, as though the rock were as soft as clay and could be moved with fingers. The stone of the door and wall seems hastily molded together.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '66',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '66': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'66. You enter a small room and your steps echo. Looking about, you\'re uncertain why, but then a wall vanishes and reveals an enormous chamber. The wall was an illusion and whoever cast it must be nearby!\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '63',
	EAST: '67',
	WEST: '65',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '67': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'67. You feel a sense of foreboding upon peering into this cavernous chamber. At its center lies a low heap of refuse, rubble, and bones atop which sit several huge broken eggshells. Judging by their shattered remains, the eggs were big enough to hold a crouching man, making you wonder how large -- and where -- the mother is.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '68',
	WEST: '66',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '68': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'68. This small chamber is a bloody mess. The corpse of a minotaur lies on the floor, its belly carved out. The creature\'s innards are largely missing, and yet you detect no other wounds. Bloody, froglike footprints track away from the corpse and out an open door.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '71',
	SOUTH: '',
	EAST: '69',
	WEST: '67',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '69': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'69. A chill crawls up your spine and out over your skin as you look upon this room. The carvings on the wall are magnificent, a symphony in stonework -- but given the themes represented, it might be better described as a requiem. Scenes of death, both violent and peaceful, appear on every wall framed by grinning skeletons and ghoulish forms in ragged cloaks.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '72',
	SOUTH: '',
	EAST: '80',
	WEST: '68',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '70': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'70. A pungent, earthy odor greets you as you pull open the door and peer into this room. Mushrooms grow in clusters of hundreds all over the floor. Looking into the room is like looking down on a forest. Tall tangles of fungus resemble forested hills, the barren floor looks like a plain between the woods, and even a trickle of water and a puddle of water that pools in a low spot bears a resemblance to a river and lake, respectively.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: '71',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '71': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'71. You pull open the door and hear the scrape of its opening echo throughout what must be a massive room. Peering inside, you see a vast cavern. Stalactites drip down from the ceiling in sharp points while flowstone makes strange shapes on the floor.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '68',
	EAST: '72',
	WEST: '70',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '72': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'72. You find this chamber lit dimly by guttering candles that squat in small hills of melted wax. The smell of their smoke hits your nose along with an odor that is reminiscent of the sea. Someone has taken a large amount of salt and drawn a broad circular symbol on the floor with the candles situated equidistantly around it. Atop the salt, someone traced the symbol with a black powder that glints a dull silver in the candlelight.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '69',
	EAST: '',
	WEST: '71',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '73': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'73. This chamber holds one occupant: the statue of a male figure with elven features but the broad, muscular body of a hale human. It kneels on the floor as though fallen to that posture. Both its arms reach upward in supplication, and its face is a mask of grief. Two great feathered wings droop from its back, both sculpted to look broken. The statue is skillfully crafted.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: '74',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '74': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'74. The door to this room swings open easily on well-oiled hinges. Beyond it you see that the chamber walls have been disguised by wood paneling, and the stone ceiling and floor are hidden by bright marble tiles. Several large and well-stuffed chairs are arranged about the room along with some small reading tables.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '76',
	SOUTH: '',
	EAST: '78',
	WEST: '75',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '75': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'75. Many small desks with high-backed chairs stand in three long rows in this room. Each desk has an inkwell, book stand, and a partially melted candle in a rusting tin candleholder. Everything is covered with dust.\n\n'+

#DM Note: The room could have been a scriptorium at some point.

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '76',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '76': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'76. You round the corner to see a ghastly scene. A semitranslucent figure hangs in the air, studded with crossbow bolts and with blood pouring from every wound. It reaches toward you in a pleading gesture, points to the walls on either side of the room, and then vanishes. Once it has gone, you notice small holes in the walls, each just large enough for a bolt to pass through.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '77',
	WEST: '75',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '77': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'77. You open the door and before you is a dragon\'s hoard of treasure. Coins cover every inch of the room, and jeweled objects of precious metal jut up from the money like glittering islands in a sea of gold.\n\n'+

#DM Note: Taking one step in the room alerts the PCs to the disappointing truth. Their feet pass silently through the illusion of the coins to strike the solid floor beneath.

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: '76',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '78': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'78. You open the door to reveal a 10-foot-by-10-foot room with a floor studded with spikes. The bones of some creature lie among the spikes and some insects scuttle away from the desiccated remains. No other doors are in the room, and it appears the door you opened was created to blend in with the walls. Additionally, you see no ceiling. You must be at the bottom of a very deep spiked pit.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '79',
	EAST: '',
	WEST: '74',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '79': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'79. You open the door to a long narrow room with a high ceiling. Three thick circles of wood rest on wooden stands. You\'re not certain what they are because you came into the room behind them.\n\n'+

#DM Note: If the PCs step in the room to get a better look, they see that each is painted with concentric circles marred by dozens of cuts into its surface. They\'re targets, and the PCs are on the wrong end of an archery range.

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '78',
	SOUTH: '80',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '80': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'80. You open the door to what must be a combat training room. Rough fighting circles are scratched into the surface of the floor. Wooden fighting dummies stand waiting for someone to attack them. A few punching bags hang from the ceiling. There\'s something peculiar about it all though. Every dummy is stocky and each has a bedraggled piece of leather hanging from its head that could be a long mask or a beard.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '79',
	SOUTH: '89',
	EAST: '81',
	WEST: '69',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '81': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'81. This small room contains several pieces of well-polished wood furniture. Eight ornate, high-backed chairs surround a long oval table, and a side table stands next to the far exit. All bear delicate carvings of various shapes. One bears carvings of skulls and bones, another is carved with shields and magic circles, and a third is carved with shapes like flames and lightning strokes.\n\n'+

#DM Note: The eight chairs represent the eight schools of magic.

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '82',
	SOUTH: '',
	EAST: '',
	WEST: '80',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '82': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'82. The strong, sour-sweet scent of vinegar assaults your nose as you enter this room. Sundered casks and broken bottle glass line the walls of this room. Clearly this was someone\'s wine cellar for a time. The shards of glass are somewhat dusty, and the spilled wine is nothing more than a sticky residue in some places. Only one small barrel remains unbroken amid the rubbish.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '81',
	EAST: '84',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '83': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'83. Looking into this room, you note four pits in the floor. A wide square is nearest you, a triangular pit beyond it, and a little farther than both lie two circular pits. The room is rectangular nearest you but it widens into a larger rounded chamber starting just beyond the rectangular pit. You note that many flagstones, ceiling tiles, and wall blocks are carved with a skull emblem of some kind, whose dark openings emulate the layout of the pits. You\'ve opened a door in the \"chin\" and are looking up at the face.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '84',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '84': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'84. This room looks like it was designed by drow. Rusted metal tiles create a huge mosaic of a spider in the floor, and someone set up rusted gratings like draperies of webs. At the far end of the chamber, the carving of a spider squats on the floor. It\'s about 3 feet tall and seems molded into the floor. Beyond it stands tall double doors of stone, their surface covered in a glittering web of gold.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '83',
	SOUTH: '',
	EAST: '86',
	WEST: '82',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '85': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'85. You peer through the open doorway into a broad, pillared hall. The columns of stone are carved as tree trunks and seem placed at random like trees in a forest. Stone root systems crawl out into the floor and marble branches expand across the ceiling. You even note a few carvings of small birds and squirrels. Beautiful as they are, the sculpting doesn\'t appear elven, and it\'s nothing dwarves would carve.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '87',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '86': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'86. This small room is lined with benchlike seats on all the walls. The seats all have holes in their top, like a privy. Facing stones on the front of the benches prevent you from seeing how deep the holes go. It looks like a communal bathroom.\n\n'+

#DM Note: The PCs may have heard that these are common in Chessenta, but that country is hundreds of miles to the east and south.

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '87',
	EAST: '',
	WEST: '84',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '87': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'87. In the center of this large room lies a 30-foot-wide round pit, its edges lined with rusting iron spikes. About 5 feet away from the pit''s edge stand several stone semicircular benches. The scent of sweat and blood lingers, which makes the pit\'s resemblance to a fighting pit or gladiatorial arena even stronger.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '86',
	SOUTH: '',
	EAST: '88',
	WEST: '85',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '88': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'88. This room is a small antechamber before two titanic bronze doors. Each stands 20 feet tall and is about 7 feet wide. The double doors are peaked at their centers, but unlike many sets of double doors, their division isn\'t in the center. Instead, the crack between the doors resembles a crooked bolt of lightning, which a figure in a cloud carved in the stone above the door appears to be hurling. The lightning bolt strikes down roughly 2 feet to the right of center. The figure in the clouds is deliberately indistinct, but it appears male, having a beard and male proportions. The stroke of bronze electricity hits a tower that seems small compared to the figure. This tower cracks down the center, continuing the gap between the doors until it reaches the ground. To either side of the tower lie pastoral scenes of hillsides dotted with sheep. There doesn\'t appear to be a lock or handles.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: '87',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '89': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'89. You poke your head through the break in the wall and look upon a room of titanic size. It is clearly an enormous mausoleum built to the proportions of giants. Huge niches are set into the walls within which you can discern giant bones. Stern-looking statues of stone giants stand 20 feet tall against the walls, and in the center of the room lies a 15-foot-long sarcophagus.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '90',
	EAST: '92',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '90': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'90. This chamber holds an odd contraption of metal and wood. It\'s a 20-foot-diameter circular platform that is tilted heavily to one side. Beneath it you can discern mechanisms that seem to attach to a large crank not far away. Above the platform hang metal weights on thin chains, which in turn are attached to discs and belts that are attached to other winches. It seems as though turning the winches turns and tilts the platform and sets the weights to moving.\n\n'+

#DM Note: This could be a training room for combat, but the PCs don\'t see any weapons inside. Certainly it would take a great deal of concentration to fight on the platform; perhaps it\'s a training room for monks or spellcasters.

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '89',
	SOUTH: '91',
	EAST: '',
	WEST: '55',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '91': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'91. You inhale a briny smell like the sea as you crack open the door to this chamber. Within you spy the source of the scent: a dark and still pool of brackish water within a low circular wall. Above it stands a strange statue of a lobster-headed and clawed woman. The statue is nearly 15 feet tall and holds the lobster claws crossed over its naked breasts.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '90',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '92': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'92. Stinking smoke wafts up from braziers made of skulls set around the edges of this room. The walls bear scratch marks and lines of soot that form crude pictures and what looks like words in some language [Goblin]. To the left lies a pile of rubbish and rubble heaped into a crude dais. The dais has upon it an ironbound chest that has been painted with a goblinlike face. Furs and skins of unknown origin are strewn haphazardly about the floor before the dais.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '93',
	WEST: '89',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '93': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'93. This small bare chamber holds nothing but a large ironbound chest, which is big enough for a man to fit in and bears a heavy iron lock. The floor has a layer of undisturbed dust upon it.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '94',
	EAST: '',
	WEST: '92',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '94': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'94. This hall is choked with corpses. The bodies of orcs and ogres lie in tangled heaps where they died, and the floor is sticky with dried blood. It looks like the orcs and ogres were fighting. Some side was the victor but you\'re not sure which one. The bodies are largely stripped of valuables, but a few broken weapons jut from the slain or lie discarded on the floor.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '93',
	SOUTH: '',
	EAST: '96',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '95': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'95. You round the corner of the hall to confront a passage nearly blocked with crates, barrels, and chests. It seems someone set them up to barricade the hall. Three barrels are set up as seats near gaps in the barricade, no doubt the place where archers waited for foes. A rusting and torn breastplate hangs from a rope near the wall.\n\n'+

#DM Note: Perhaps the breastplate served as a warning gong.

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '96',
	EAST: '99',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '96': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'96. You smelled smoke as you moved down the hall, and rounding the corner into this room you see why. Every surface bears scorch marks and ash piles on the floor. The room reeks of fire and burnt flesh. Either a great battle happened here or the room bears some fire danger you cannot see for no flames light the room anymore.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '95',
	SOUTH: '97',
	EAST: '',
	WEST: '94',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '97': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'97. This hall stinks with the wet, pungent scent of mildew. Black mold grows in tangled veins across the walls and parts of the floor. Despite the smell, it looks like it might be safe to travel through. A path of stone clean of mold wends its way through the hallway.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '96',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '98': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'98. You open the door and a gout of flame rushes at your face. A wave of heat strikes you at the same time and light fills the hall. The room beyond the door is ablaze! An inferno engulfs the place, clinging to bare rock and burning without fuel.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '',
	EAST: '',
	WEST: '99',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '99': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'99. You peer into this room and spot the white orb of a skull lying on the floor. Suddenly a stone falls from the ceiling and smashes the skull to pieces. An instant later, another stone from the ceiling drops to strike the floor and shatter. You hear a low rumbling and cracking noise.\n\n'+

#DM Note: The ceiling caves in during the next round.

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '',
	SOUTH: '100',
	EAST: '98',
	WEST: '95',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
 '100': {
	ZONENAME: 'start',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION: 

'100. Dozens of dead, winged beings lie scattered about the floor, each about the size of a cat. Their broken bodies are batlike and buglike at the same time. Each had two sets of bat wings, a long nose like a mosquito, and six legs, but many were split in half or had limbs or wings lopped off. Their forms are little more than dried husks now, and there\'s no sign of what killed them.\n\n'+

'To the North is a Door\n'+'To the South is a Door\n'+'To the East is a Door\n'+'To the West is a Door\n\n',

	SOLVED: False,
	NORTH: '99',
	SOUTH: '',
	EAST: '',
	WEST: '',
        UP: '',
        DOWN: '',
        ITEM: '\n',
  },
}


