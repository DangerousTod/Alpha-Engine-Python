
#               CSV-LAYOUT
# USER_CMD          SELECTION       COPPER_COST
# BUY_CHAINMAIL     chainmail       99


WEAPON_DICT = []
ZONENAME = 'blacksmith'
DESCRIPTION = 'description'
UP = 'up'
DOWN = 'down'
RIGHT = 'right'
LEFT = 'left'
BUY = 'buy'


weapon_dict = {
  'helmet': {
	ZONENAME: 'blacksmith',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'You are looking at the Helmet.\nThe Helmet is above the Chainmail \n'+
'and to the left of the Spear.\n'+
'Commands are: Left Right Up Down or \n'+
'Buy This Item: Buy\n',

    UP: '',
    DOWN: 'chainmail',
    RIGHT: 'spear',
    LEFT: '',
    BUY: 'buy',
  },
 'chainmail': {
	ZONENAME: 'blacksmith',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'You are looking at the Chainmail.\nThe Chainmail is below the Helmet \n'+
'and to the left of the Spear.\n'+
'Commands are: Left Right Up Down or \n'+
'Buy This Item: Buy\n',

    UP: 'helmet',
    DOWN: '',
    RIGHT: 'spear',
    LEFT: '',
    BUY: 'buy',    
  },
 'spear': {
	ZONENAME: 'blacksmith',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'You are looking at the Spear.\nThe Spear is below the Sword, above \n'+
'the Chainmail, and to the right of the Helmet.\n'+
'Commands are: Left Right Up Down or \n'+
'Buy This Item: Buy\n',

    UP: '',
    DOWN: 'chainmail',
    RIGHT: 'sword',
    LEFT: 'helmet',
    BUY: 'buy',
  },
 'sword': {
	ZONENAME: 'blacksmith',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'You are looking at the Sword.\nThe Sword is to the left of the Spear.\n'+
'Commands are: Left Right Up Down or \n'+
'Buy This Item: Buy\n',

    UP: '',
    DOWN: '',
    RIGHT: '',
    LEFT: 'spear',
    BUY: 'buy',
  },
 'shovel': {
	ZONENAME: 'blacksmith',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'You are looking at the Shovel.\nThe Shovel is below the Flail, \n'+
'above the Scimitar and to the right of the Sword.\n'+
'Commands are: Left Right Up Down or \n'+
'Buy This Item: Buy\n',

    UP: 'flail',
    DOWN: 'scimitar',
    RIGHT: 'axe',
    LEFT: 'sword',
    BUY: 'buy',
  },
 'axe': {
	ZONENAME: 'blacksmith',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'You are looking at the Axe.\nThe Axe is to the right of the \n'+
' the Scimitar.\n'+
'Commands are: Left Right Up Down or \n'+
'Buy This item: Buy\n',

    UP: '',
    DOWN: '',
    RIGHT: '',
    LEFT: 'scimitar',
    BUY: 'buy',
  },
 'scimitar': {
	ZONENAME: 'blacksmith',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'You are looking at the Scimitar.\nThe Scimitar \n' +
'is below the shovel and to the left of the Axe.\n'+
'Commands are: Left Right Up Down or \n'+
'Buy This Item: Buy\n',

    UP: 'shovel',
    DOWN: '',
    RIGHT: 'axe',
    LEFT: '',
    BUY: 'buy',
  },
 'flail': {
	ZONENAME: 'blacksmith',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'You are looking at the Flail.\nThe Flail is above the Shovel.\n'+
'Commands are: Left Right Up Down or \n'+
'Buy This Item: Buy\n',

    UP: '',
    DOWN: 'shovel',
    RIGHT: '',
    LEFT: '',
    BUY: 'buy',
  },
 'buy': {
	ZONENAME: 'blacksmith',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'You will purchase this Item.\n',

    UP: '',
    DOWN: '',
    RIGHT: '',
    LEFT: '',
    BUY: '',
  },
}

