#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 24 15:17:30 2020

@author: jengwall
"""


#from Items import *
#from Players import *
#from Lists import *
#from Rooms import *

#print("Second Module's Name: {}".format(__name__))
#import textwrap
#import sys
#sys.setrecursionlimit(10000)
#import os
#import re
#import random
#import time
#from time import sleep
#import math
#import csv
#import functools


class Thing:
  def __init__(self):
    self.name = ''
    self.contents = []
thing = Thing()

class Storage:
  def __init_(thing):
    backpack.name = ''
    backpack.contents = []
backpack = Storage()

class Living:
  def __init__(self):
    self.name = ''
    self.location = []
    self.health = ()
living = Living()

class Entity:
  def __init__(self, name, attack, magic, health, location, information, card, open_link, game_over):
    self.name = name
    self.attack = attack
    self.magic = magic
    self.health = health
    self.location = location
    self.information = information
    self.card = card
    self.open_link = open_link
    self.game_over = game_over

    def player_holding_length(self, name):
      with open('./Players/' + self.name + '/holding.txt','r') as file:
        holding_len = file.readlines()
        holding_length = len(holding_len)
        return holding_length

    def player_holding_contents(self, name):
      with open('./Players/' + self.name + '/holding.txt','r') as file:
        isHoldings = file.readlines()
        return isHoldings

    def player_holding(self, name):
      with open('./Players/' + self.name + '/holding.txt','r') as file:
        holding = file.read()
        return holding

    def player_wearing_length(self, name):
      with open('./Players/' + self.name + '/wearing.txt','r') as file:
        wearing_len = file.readlines()
        wearing_length = len(wearing_len)
        return wearing_length

    def player_wearing_contents(self, name):
      with open('./Players/' + self.name + '/wearing.txt','r') as file:
        isWearings = file.readlines()
        return isWearings

    def player_wearing(self, name):
      with open('./Players/' + self.name + '/wearing.txt','r') as file:
        wearing = file.read()
        return wearing
    

player = Entity(
        '',
        (),
        (),
        100,
        'xxxxxxxxx',
        ' ',
        '',
        False,
        False
)




def player_get_attack():
  player.name = player.name
    
  with open('./Players/' + player.name + '/holding.txt','r') as file:
    my_weapons = file.read()
    if '' in my_weapons:
      player.attack += 1
    if 'Bronze Sword' in my_weapons:
      player.attack += 5
    if 'Shovel' in my_weapons:
      player.attack += 6
    if 'Wand' in my_weapons:
      player.attack += 2
      player.magic += 1
      
    playerattack = (int(player.attack) + int(player.magic))
    return playerattack

def player_get_weapon():
  player.name = player.name
  playerweapon = ''
  file = open('./Players/' + player.name + '/holding.txt','r')
  my_weapons = file.read()
  if '' in my_weapons:
    playerweapon = 'bare hands'
  elif 'Bronze Sword' in my_weapons:
    playerweapon = 'bronze sword'
  elif 'Shovel' in my_weapons:
    playerweapon = 'shovel'
  elif 'Wand' in my_weapons:
    playerweapon = 'wand'
  else:
    alt_second_module.prompt()
  file.close()
  return playerweapon

def player_get_dam_mesg():
  player.name = player.name
  player_dam_mesg = []
  file = open('./Players/' + player.name + '/holding.txt','r')
  my_weapons = file.read()
  if '' in my_weapons:
    player_dam_mesg = ['scratch','punch','slap']
  elif 'Bronze Sword' in my_weapons:
    player_dam_mesg = ['land a wild slash','open a deep cut','sink in a nice jab']
  elif 'Shovel' in my_weapons:
    player_dam_mesg = ['make contact with a solid whack','send a split down the middle','swing upward and land a hard smack']
  elif 'Wand' in my_weapons:
    player_dam_mesg = ['send a sizzling blast','call up a cone of freeze','summon a terrific blast']
  else:
    alt_second_module.prompt()
  file.close()
  return player_dam_mesg

class Enemy:
  def __init__(self, health, attack, name, dead=''):
    self.health = health
    self.attack = attack
    self.name = name
    self.dead = dead
ai = Enemy(
        (),
        (),
        '',
        ''
)


