#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May  7 15:00:53 2020

@author: jengwall
"""
import Class
from Class import player
import stockroom


WEAPON_DICT = []
ZONENAME = ''
DESCRIPTION = 'description'
UP = 'up'
DOWN = 'down'
RIGHT = 'right'
LEFT = 'left'
BUY = 'buy'

def select_purchase(playerinfomation, open_link=True):
  import alt_second_module
  import stockroom
  from stockroom import weapon_dict
  playerinformation = player.information
  weapon_list = ['helmet','chainmail','spear','sword','shovel','axe','scimitar','flail']
#  choose_item = player.information.lower()
  print('' + stockroom.weapon_dict[player.information][DESCRIPTION] + '   ')

  Option = input("ADVENTURE QUALITY GEAR THE BRANDS YOU TRUST\n")
  Options = ['up', 'down', 'left', 'right', 'yes','Yes']
  if Option in ['buy']:
#    player.open_link = False
    time.sleep(10)
    Blacksmith = "What is your selection?"
    WeaponPurchase = input(Blacksmith)
    
    if WeaponPurchase.lower() in weapon_list:     
      sale(WeaponPurchase, open_link=True) 
                      # shoppingbg.py
  else:
    show_dict(Option, open_link=True)


def show_dict(Option, open_link=True):
  Options = ['up', 'down', 'left', 'right', 'yes','Yes']
  if Option in ['up']:
    pointer = stockroom.weapon_dict[player.information][UP]
    next_item(pointer, open_link=True)
  elif Option in ['down']:
    pointer = stockroom.weapon_dict[player.information][DOWN]
    next_item(pointer, open_link=True)
  elif Option in ['left']:
    pointer = stockroom.weapon_dict[player.information][LEFT]
    next_item(pointer, open_link=True)
  elif Option in ['right']:
    pointer = stockroom.weapon_dict[player.information][RIGHT]
    next_item(pointer, open_link=True)
#  else:
#    print("Take your time.")

#def next_item(pointer):
    
#  if pointer.strip():

#    Newplayerinformation = pointer

#    show_next_item(Newplayerinformation, open_link=True)
#  else:
#    print("It can be confusing, left or right, up or down; lest ye choose to buy.")                     



#def show_next_item(Newplayerinfomation):
def next_item(pointer, open_link=True):
  import alt_second_module
  import stockroom
  from stockroom import weapon_dict
  playerinformation = player.information
  weapon_list = ['helmet','chainmail','spear','sword','shovel','axe','scimitar','flail']
#  choose_item = player.information.lower()
#  print('' + stockroom.weapon_dict[player.information][DESCRIPTION] + '   ')
  print('' + stockroom.weapon_dict[pointer][DESCRIPTION] + '   ')

  Option = input("ADVENTURE QUALITY GEAR THE BRANDS YOU TRUST\n")
  Options = ['up', 'down', 'left', 'right', 'yes','Yes']
  if Option == 'buy':
#    player.open_link = False
    Blacksmith = "What is your selection?"
    WeaponPurchase = input(Blacksmith)
    
    if WeaponPurchase.lower() in weapon_list:     
      sale(WeaponPurchase, open_link=True) 
                      # shoppingbg.py
  else:
    show_dict(Option, open_link=True)


