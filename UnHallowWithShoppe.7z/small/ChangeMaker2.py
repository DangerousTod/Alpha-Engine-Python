#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May  7 16:17:47 2020

@author: jengwall
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon May  4 12:14:17 2020

@author: jengwall
"""
import numpy as np

types = ["Plutons","Corwyns","Rogers","Nickels","Steels","Coppers"]
denominations = np.array([57,31,11,7,3,1]) 
stores = np.array([13,22,50,50,200,300])
start = denominations.dot(stores)
drawer = denominations.dot(stores)           # total cash on hand
mints = np.array([0,0,2,10,30,55])
wallet = denominations.dot(mints)            # total player cash
quantity =  600
toReturn = np.empty([])
end = start - quantity 

print("You have a total of: ", wallet, " Coppers to spend.")
print("Thank Ye for Ye business\n\nI owe Ye a few Coppers. Now that will be...")
def returnChange(change, denominations):
    for i in range(len(stores)):
    
        toGiveBack = [0] * len(denominations)
        for pos, coin in enumerate(denominations):
            while coin <= change:

                stores[pos] -= 1
                mints[pos] += 1
                change = change - coin
                toGiveBack[pos] += 1

        return(toGiveBack)
toReturn  = returnChange(quantity,denominations)

#print(returnChange(quantity,denominations))
print("The total being ", toReturn[0], " Plutons, ",toReturn[1]," Corwyns,", toReturn[2]," Rodgers,", toReturn[3]," Nickels, ", toReturn[4],"Steels and, ", toReturn[5],"Coppers")
print("Me having ", stores[0], " Plutons, ",stores[1]," Corwyns,", stores[2]," Rodgers,", stores[3]," Nickels, ", stores[4],"Steels and, ", stores[5],"Coppers")
print("And you have yourself a full purse of ", mints[0], " Plutons, ",mints[1]," Corwyns,", mints[2]," Rodgers,", mints[3]," Nickels, ", mints[4],"Steels and, ", mints[5],"Coppers")
print("Me cash-on-hand is now ", end, " Total copper coins.")
print("Be shore to come again.")

