CART = []
TOTAL = 1
SELECTION = 'chainmail'         # will come from CSV
COPPER_COST = 99                # will come from CSV
FINAL_COST = TOTAL + COPPER_COST



def sale():
    CART.append(SELECTION)
    TOTAL + COPPER_COST
    print(CART)
    print(FINAL_COST)


sale()