
#               CSV-LAYOUT
# USER_CMD          SELECTION       COPPER_COST
# BUY_CHAINMAIL     CHAINMAIL       99


WEAPON_DICT = []
ZONENAME = 'blacksmith'
DESCRIPTION = 'description'
UP = 'up'
DOWN = 'down'
RIGHT = 'right'
LEFT = 'left'
BUY = 'buy'


weapon_dict = {
  'HELMET': {
	ZONENAME: 'blacksmith',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'\nADVENTURE QUALITY GEAR THE BRANDS YOU TRUST\n'+
'You are looking at the Helmet.\n\n'+
'This is one mean looking steel hat.\n'+
'Clearly forged by makers who know about \n'+
'what it means to be in battle!\n\n'+
'To the right of the Helmet is the Chainmail.\n',
#'Commands are: Left Right Up Down or Buy\n'+
#'Command: \n',

    UP: '',
    DOWN: '',
    RIGHT: 'CHAINMAIL',
    LEFT: '',
#    BUY: 'buy',
  },
 'SHOVEL': {
	ZONENAME: 'blacksmith',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'\nADVENTURE QUALITY GEAR THE BRANDS YOU TRUST\n'+
'You are looking at the Shovel.\n\n'+
'Digging is no swea with this stubby little \n'+
'shovel. It has a nice wide face and good \n'+
'sturdy grip. It looks great too.\n\n'+
'To the right of the Shovel is the Sword, to the \n'+
'left is the Axe, above is the Flail, and below the Shovel \n'+
'is the Scimitar.\n',
#'Commands are: Left Right Up Down or Buy\n'+
#'Command: \n',

    UP: 'FLAIL',
    DOWN: 'SCIMITAR',
    RIGHT: 'SWORD',
    LEFT: 'AXE',
#    BUY: 'buy',
  },
 'CHAINMAIL': {
	ZONENAME: 'blacksmith',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'\nADVENTURE QUALITY GEAR THE BRANDS YOU TRUST\n'+
'You are looking at the Chainmail.\n\n'+
'Nothing is more stylish than the silvery sheen \n'+
'of glimmering rings of woven steel. You can wear \n'+
'this shirt with pride.\n\n'+
'To the right of the Chainmail is the Axe, to the \n'+
'left is the Helmet, above is the Spear, and below \n'+
'the Chainmail is the Dagger.\n',
#'Commands are: Left Right Up Down or Buy\n'+
#'Command: \n',

    UP: 'SPEAR',
    DOWN: 'DAGGER',
    RIGHT: 'AXE',
    LEFT: 'HELMET',
#    BUY: 'buy',    
  },
 'SPEAR': {
	ZONENAME: 'blacksmith',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'\nADVENTURE QUALITY GEAR THE BRANDS YOU TRUST\n'+
'You are looking at the Spear.\n\n'+
'Not for the faint of heart, this iron-headed, \n'+
'leafblade spear mind you; spears are for \n'+
'warriors and grunts; pushing the line!\n\n'+
'Below the Spear is the Chainmail.\n',
#'Commands are: Left Right Up Down or Buy\n'+
#'Command: \n',

    UP: '',
    DOWN: 'CHAINMAIL',
    RIGHT: '',
    LEFT: '',
#    BUY: 'buy',
  },
 'DAGGER': {
	ZONENAME: 'blacksmith',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'\nADVENTURE QUALITY GEAR THE BRANDS YOU TRUST\n'+
'You are looking at the Dagger.\n\n'+
'There must be about a thousand places to \n'+
'stick a man besides in the dark...\n'+
'~Unknown\n\n'+
'Above the Dagger is the Chainmail.\n',
#'Commands are: Left Right Up Down or Buy\n'+
#'Command: \n',

    UP: 'CHAINMAIL',
    DOWN: '',
    RIGHT: '',
    LEFT: '',
#    BUY: 'buy',
  },     
 'SWORD': {
	ZONENAME: 'blacksmith',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'\nADVENTURE QUALITY GEAR THE BRANDS YOU TRUST\n'+
'You are looking at the Sword.\n\n'+
'Strap this to your side, your back, your \n'+
'horse, stand it in the corner, hang it by \n'+
'the door; just carry it around!\n\n'+
'To the left of the Sword is the Shovel.\n',
#'Commands are: Left Right Up Down or Buy\n'+
#'Command: \n',

    UP: '',
    DOWN: '',
    RIGHT: '',
    LEFT: 'SHOVEL',
#    BUY: 'buy',
  },
 'AXE': {
	ZONENAME: 'blacksmith',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'\nADVENTURE QUALITY GEAR THE BRANDS YOU TRUST\n'+
'You are looking at the Axe.\n\n'+
'An axe is the original multi tool designed \n'+
'by nature herself when all were young.\n'+
'This one looks quite nice.\n\n'+
'To the right of the Axe is the Shovel, and\n'+
'to the left of the Axe is the Chainmail.\n',
#'Commands are: Left Right Up Down or Buy\n'+
#'Command: \n',

    UP: '',
    DOWN: '',
    RIGHT: 'SHOVEL',
    LEFT: 'CHAINMAIL',
#    BUY: 'buy',
  },
 'SCIMITAR': {
	ZONENAME: 'blacksmith',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'\nADVENTURE QUALITY GEAR THE BRANDS YOU TRUST\n'+
'You are looking at the Scimitar.\n\n'+
'Scimitars are for slashing and slinging wildly.\n'+
'Those who learn of these dark arts are those \n'+
'who are few. Seek them out, Adventurer.\n\n'+
'Above the Scimitar is the Shovel.\n',
#'Commands are: Left Right Up Down or Buy\n'+
#'Command: \n',

    UP: 'SHOVEL',
    DOWN: '',
    RIGHT: '',
    LEFT: '',
#    BUY: 'buy',
  },
 'FLAIL': {
	ZONENAME: 'blacksmith',
####################EIGHTY#COLUMNS##############################################
	DESCRIPTION:
'\nADVENTURE QUALITY GEAR THE BRANDS YOU TRUST\n'+
'You are looking at the Flail.\n\n'+
'Truly a ghastly creation of heavy headed barbed \n'+
'hooks on a too-thick shaft. Short chains bring \n'+
'the dangerous creation to whistling life.\n\n'+
'Below the Flail is the Shovel.\n',
#'Commands are: Left Right Up Down or Buy\n'+
#'Command: \n',

    UP: '',
    DOWN: 'SHOVEL',
    RIGHT: '',
    LEFT: '',
#    BUY: 'buy',
  },
# 'CHAINMAIL': {
#	ZONENAME: 'blacksmith',
####################EIGHTY#COLUMNS##############################################
#	DESCRIPTION:
#'\nADVENTURE QUALITY GEAR THE BRANDS YOU TRUST\n'+
#'You are looking at the Chainmail.\n'+
#'To the right of the Chainmail is the , to the \n'+
#'left is the , above is the , and below \n'+
#'the Chainmail is the .\n'+
#'is the .\n',
#'Commands are: Left Right Up Down or Buy\n'+
#'Command: \n',

#    UP: '',
#    DOWN: '',
#    RIGHT: '',
#    LEFT: '',
##    BUY: 'buy',    
#  },
}

