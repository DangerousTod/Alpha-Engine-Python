#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 19 20:41:14 2020

@author: jengwall
"""

#######################################################################################################
#         developed by Jonathan Engwall, October of 2018 in Tijuana, MX                               #
#               PYTHON CMD CRUD MUD: FEAR THEE TREAD INTERACTIVE FICTION                              #
#         	ENGWALLJONATHANTHEREAL@GMAIL.COM **2018**                                             #
#######################################################################################################

import textwrap
import sys
sys.setrecursionlimit(10000)
import os
import re
import random
import time
from time import sleep
import math
import csv
import functools

import alt_first_module

#alt_second_module.get_backpack_contents()
#alt_second_module.main_game_loop()
#######################################################################################

from Items import *
from Players import *
from Lists import *
from Rooms import *

def setup_game():
  from Class import Entity
#  player = player()
  question = "Greetings adventurer. What's your name?\n"
  for character in question:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)
    name = input("Your Name: ")
    if bool(re.match("^[A-Za-z0-9]*$", name)) == False:
      print("Use only Letters or Numbers without Whitespace.\n")
      time.sleep(0.04)
      setup_game()
    if name == '':
      print("Use Letters or Numbers to create your player.name.\n")
      time.sleep(0.04)
      setup_game()
    else:
      welcome = "Okay, " + name + " let's begin. You need to know a few things.\n"
      for character in welcome:
        sys.stdout.write(character)
#        sys.stdout.flush()
#        time.sleep(0.03)

#        sys.stdout.flush()
#        time.sleep(0.08) # was time.sleep(0.08)
#        os.system('clear')
#        os.chdir("..")
        os.chdir("./Players/")
        os.system("mkdir " + name + "")
        os.chdir("" + name + "")
#        os.system("cd ./Players/" + name)
#        os.system("mkdir " + name)

#        os.system("cd " + name)
        
        os.system("touch __init__.py")
        os.system("touch holding.txt")
        os.system("touch wearing.txt")
        os.system("touch startlocation.txt")
        
        
#        os.system("touch ./Players/" + name + "/__init__.py")
#        os.system("touch ./Players/" + name + "/holding.txt")
#        os.system("touch ./Players/" + name+ "/wearing.txt")
#        os.system("touch ./Players/" + name+ "/startlocation.txt")
        os.chdir("..")
        os.chdir("..")
#        os.system("cd ..")
#        os.system("cp -r ./Rooms/* ./Players/" + name)
        
        holding_stripe(name)
        wearing_stripe(name)
        starting_stripe(name)
        player_files(name)
        new_holding(name)
        run_intro(name)
#        player.name = name
#        player.name = player.name

#        print('\n\nWelcome to the Border Land!\nWhat adventure awaits!\n\n')
        playerlocation = 'xxxxxxxxx'
#        print('Pinklemire Street.\n.\n\n')
#        print("To the North is the Blacksmith\nTo the South is the Message Post\nTo the East is the Leather Shop\nTo the West is the Pub\n")
#        with open('./Players/' + name + '/xxxxxxxxx.txt','r+') as file:
#          things = file.readlines()
#          print("Things here: \n")
#          for thing in things:
#            print(thing)
#          player.name=player.name
        playername = name
        import alt_second_module
        alt_second_module.main_game_loop(playername, playerlocation)  
        





def wearing_stripe(name):

  file = open('./Items/wearing.txt','r')
  basics = file.readlines()
  inv = open('./Players/' + name + '/wearing.txt','w+')
  for basic in basics:
    inv.write(basic)
    continue
  file.close()
  inv.close()
  

  
def run_intro(name):
#  player.name = player.name
  weaponOrTool_stripe()
  clothing_stripe()
  os.system('clear')


def holding_stripe(name):

  file = open('Items/holding.txt','r')
  basics = file.readlines()
  with open('Players/' + name + '/holding.txt','w+') as h_inv:
    for basic in basics:
      h_inv.write(basic)
      continue
    file.close()
#  h_inv.close()

def wearing_stripe(name):

  file = open('./Items/wearing.txt','r')
  basics = file.readlines()
  inv = open('./Players/' + name + '/wearing.txt','w+')
  for basic in basics:
    inv.write(basic)
    continue
  file.close()
  inv.close()
  
def starting_stripe(name):

  file = open('./Lists/startlocation.txt','r')
  basics = file.readlines()
  inv = open('./Players/' + name + '/startlocation.txt','w+')
  for basic in basics:
    inv.write(basic)
    continue
  file.close()
  inv.close()
 
def clothing_stripe():
  file = open('./Lists/clothing.txt','r')
  file.close()

def weaponOrTool_stripe():
  file = open('./Lists/weaponOrTool.txt','r')
  file.close()
  
def player_files(name):
  file = open('./Players/' + name + '/wearing.txt','r')
  file.close()

def new_holding(name):
  file = open('./Players/' + name + '/holding.txt','r')
  file.close() 
  

  
    
