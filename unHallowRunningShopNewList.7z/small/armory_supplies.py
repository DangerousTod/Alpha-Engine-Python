#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May  7 15:00:53 2020

@author: jengwall
"""
import Class
from Class import player
import stockroom


WEAPON_DICT = []
ZONENAME = ''
DESCRIPTION = 'description'
UP = 'up'
DOWN = 'down'
RIGHT = 'right'
LEFT = 'left'
BUY = 'buy'

def select_purchase(playername, playerlocation, playerinfomation):
  import alt_second_module
  import stockroom
  from stockroom import weapon_dict
  playerinformation = player.information
  weapon_list = ['helmet','chainmail','spear','sword','shovel','axe','scimitar','flail','dagger']

  print('' + stockroom.weapon_dict[player.information][DESCRIPTION] + '   ')

  Option = input("Commands are: Left <=> Right <=> Up <=> Down <=> Buy\n" +
                 "Enter to Escape. Command: ")
  Options = ['up', 'down', 'right', 'left','buy']
  if Option == 'buy':
    player.open_link = True
    playerinformation = player.information
    sale(playername, playerlocation, playerinformation)
    
  elif Option in ['up', 'down', 'right', 'left']:
    option = Option
    player.open_link = True
    show_dict(playername, playerlocation, option)
  else:
    print("this is not an option.")
    player.open_link = False
    alt_second_module.player_look(playername, playerlocation)


def show_dict(playername, playerlocation, option):

  if option == 'up':
    pointer = stockroom.weapon_dict[player.information][UP]
    next_item(playername, playerlocation, pointer)
  elif option == 'down':
    pointer = stockroom.weapon_dict[player.information][DOWN]
    next_item(playername, playerlocation, pointer)
  elif option == 'right':
    pointer = stockroom.weapon_dict[player.information][RIGHT]
    next_item(playername, playerlocation, pointer)
  elif option == 'left':
    pointer = stockroom.weapon_dict[player.information][LEFT]
    next_item(playername, playerlocation, pointer)



def next_item(playername, playerlocation, pointer):
  import alt_second_module
  import stockroom
  from stockroom import weapon_dict
  player.information = pointer
  weapon_list = ['helmet','chainmail','spear','sword','shovel','axe','scimitar','flail','dagger']

  print('' + stockroom.weapon_dict[player.information][DESCRIPTION] + '   ')

  Option = input("Commands are: Left <=> Right <=> Up <=> Down <=> Buy\n" +
                 "Enter to Escape. Command: ")
  Options = ['up', 'down', 'right', 'left','buy']
  if Option == 'buy':
    playerinformation = player.information
    sale(playername, playerlocation, playerinformation) 
                      # shoppingbg.py
  elif Option in ['up', 'down', 'right', 'left']:
    option = Option
    show_dict(playername, playerlocation, option)
  else:
    print("this is not an option.")
    player.open_link = False
    alt_second_module.player_look(playername, playerlocation)


