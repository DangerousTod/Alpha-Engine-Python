#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 19 20:42:10 2020

@author: jengwall
"""

import textwrap
import sys
sys.setrecursionlimit(10000)
import os
import re
import random
import math
import csv
import functools

#######################################################################################

from time import sleep
import Map

from Items import *
from Players import *
from Lists import *
from Rooms import *

import Class
from Class import player

ZONEMAP = []
ZONENAME= ''
DESCRIPTION = 'description'
EXAMINATION = 'examine'
SOLVED = False
NORTH = 'north'
SOUTH = 'south'
EAST = 'east'
WEST = 'west'
UP = 'up'
DOWN = 'down'
PRICES = 'prices'
EXIT = 'north'
DEATH = 'death'
ESCAPE = 'escape'
NO_MOVE = 'no_move'
ITEM = 'item'

def main_game_loop(playername, playerlocation):
#  os.chdir("..")
  from Class import player
#  print(self.health)
  while player.game_over is False:
    prompt(playername, playerlocation)
    
def load_backpack(playername, playerlocation):
#  playername = savename
#  playerlocation = savelocation
  player.game_over = True 
  action = input("Save Game For You?\nYes or No: \n")
  if action == 'yes':
    os.chdir("Lists/")
    with open('player_card.txt') as file:       # saves player name
      saved_games = file.read()
      for saved_game in saved_games:
        if playername not in saved_games:
          file.write("\n" + str(playername) + "")
    os.chdir("..")
    print("Good Day, Sir!")
#  location = player.location
    action = input("Save your current location?\nYes or No.\n")
    if action in 'no':

      os.chdir("Players/")
      os.chdir("" + playername + "/")
      with open("startlocation.txt") as file:
        
        file.write("xxxxxxxxx")
        file.close("startlocation.txt")
#    os.system("")
#    os.system("")
#    os.system("")
#    os.system("w")
#    os.system("q")
      sys.exit(0)
    elif action in 'yes':
#    os.system("ed ./Players/" + playername + "/startlocation.txt")
#    os.system("a")
#    os.system("" + playerlocation + "")
#      os.chdir("Players/")
#      os.chdir("" + playername + "/")
      file = open('./Players/' + playername + '/startlocation.txt','w+')
#      with open("startlocation.txt") as file:
        
      file.write(playerlocation)
#      file.close("startlocation.txt")
      file.close()
#    os.system(".")
#    os.system("w")
#    os.system("q")
      sys.exit(0)
  else:
    end_game(playername)


#def save_name(playername):
#  with open('./Lists/player_card.txt') as file:
#    players = file.read()
#    for player in players:
#      if playername not in players:
#        file = open('./Lists/player_card.txt','w+')
#        file.write(playername)
#        file.close
#        print("Well then Good Day, Sir!")
#        sys.exit(0)
#      else:
#        print("Well then Good Day, Sir!")
#        sys.exit(0)
        
        
        
        
        
#  file = open('./Lists/player_card.txt','r')
#  playername = my_player.name.lower()
#  players = file.read()
#  if playername not in players:
#    file.close()
 #   file = open('./Lists/player_card.txt','a+')
 #   file.write('\n' + playername + '')
#    file.close
#    close_all_files()
#  else:
#    file.close()
#    close_all_files()


#######################################################################################################
#                                                                                                     #                                     delete   
#                                                                                                     #
#######################################################################################################

def end_game(playername):
#  playername = my_player.name
  print("Ending session...")
  with open('./Lists/player_card.txt','r') as file:
    players = file.readlines()
    with open('./Lists/player_card.txt','w+') as remove_player:
      for player in players:
        if player != name:
          remove_player.write(playername)
          continue
        continue
#  os.system("cd ./Players/")
  os.system("rm -rf /Players/" + playername + "")
  os.system("y")
  sys.exit(0)


def prompt(playername, playerlocation):
  print('show more - move - look - options - status - quit')
#  global playerlocation
  playerlocation = player.location
 
#  global playername
  playername = player.name
  global action
  action = input("Command: ")
  actions = ['climb ladder','quit','look','move','options','status','show more']
  if action.lower() not in actions:
    print('Command unrecognized.\n')
    prompt(playername, playerlocation)
  elif action.lower() == ("quit"):
    load_backpack(playername, playerlocation)

###################################################################################################
  elif action.lower() in ['move']:
    player_move(playername, playerlocation)
    return
  elif action.lower() in ['look']:
    player_look(playername, playerlocation)
  elif action.lower() in ['options']:
    player_options(action.lower())
    return
  elif action.lower() in ['status']:
    player_status(action.lower())
    return
  elif action.lower() in ['show more']:
    show(playername, playerlocation)

def get_backpack_contents():
  file = open('./Lists/player_card.txt','r')
  contents = file.read()
  print(contents)
  file.close()
  player.name = input("\nChoose the player to resume from this list\nChoose player: \n")
  file = open('./Lists/player_card.txt','r')
  strict = file.read()
  if player.name == '':
    sys.exit(0)
  elif player.name.lower() in strict.lower():
    file.close()
    os.system('clear')
#    player.name = player.name
    hold_ready("" + player.name + "")################<<<<<<<<<<<<<<<<<<<<<############,
  else:
    file.close()
    os.system('clear')
    message = "Player not found.\nRemember to match spelling and capitalization."
    import startup
    startup.title_screen_message(message)
    
def restart(new_start):
  player.game_over = False
#  print("restart statement\n")
  player.location = new_start
  playerlocation = player.location.lower()
#  print('\n' + player.location.upper() + '')
  print('' + zonemap[new_start][DESCRIPTION] + ' ')
  with open('./Players/' + player.name + '/' + player.location + '.txt','r') as file:
    things = file.readlines()
    print("Things here: \n")
    for thing in things:
      print(thing)
    first_module.main_game_loop()

def print_start_location(playername):
#  print("start statement\n")
  with open('./Players/' + player.name + '/startlocation.txt') as location_line:
    csv_reader = csv.reader(location_line, delimiter= ',')
    line_count = 0
    for row in csv_reader:
      new_start = ('' + (f'{"".join(row)}' + ''))
      line_count += 1
    restart(new_start)


def run_game(playername):
  player.name = player.name
  treasure_stripe()
  weaponOrTool_stripe()
  clothing_stripe()
  os.system('clear')
  welcome = "\n\n\nWelcome to the Under Kingdom\n"
  for character in welcome:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.1)
    
def list_ready(playername):
#  print("list statement\n")
  file = open('./Players/' + player.name + '/treasuryList.txt','r')
  file.close()
  player.name = player.name
  file = open('./Players/' + player.name + '/startlocation.txt','r')
  startlocation = file.read()
  file.close()
  if startlocation == 'xxxxxxxxx' or startlocation == 'ccccccccc' or startlocation == 'vvvvvvvvv' or startlocation == 'bbbbbbbbb' or startlocation == 'nnnnnnnnn' or startlocation == '1_1':
    startlocation = 'xxxxxxxxx'
#    print("1_1 restart statement\n")
    player.game_over = False
    run_game(playername)
  else:
#    print("print start statement\n")
    player.game_over = False
    print_start_location(playername)    


def wear_ready(playername):
#  print("wear statement\n")
  file = open('./Players/' + player.name + '/wearing.txt','r')
  file.close()
  inv_ready(playername)

def hold_ready(playername):
#  print("hold statement\n")
  with open('./Players/' + player.name +'/holding.txt','r') as file:
    living_check = file.read()
    if 'silver skull' in living_check:
      message = "This player is dead.\n"
      file.close()
      os.system('clear')
      title_screen_message(message)
    else:
      file.close()
      wear_ready(playername)

#######################################################################################################
#       success!!!!!                                                                                  #
#                                                desc first room                                      #
#######################################################################################################



  print('\n\nTerrible Luck!\nYou fell through a crack in the ceiling above. It is a good thing you bought all those supplies when you were in town!\n\n')
  player.location = '1_1'
  print('Oubliette.\nA crack in the ceiling above the middle of the north wall allows a trickle of water to flow down to the floor. The water pools near the base of the wall, and a rivulet runs along the wall an out into the hall. The water smells fresh.\n\n')
  print("To the South is a Door\nTo the West is a Door\n")
  with open('./Players/' + player.name + '/xxxxxxxxx.txt','r') as file:
    things = file.readlines()
    print("Things here: \n")
    for thing in things:
      print(thing)
      main_game_loop(playername)


def print_special_location(destination, playername):

  import Map
  from Map import zonemap
  from Map import ZONENAME
  from Map import conditions
  import armory_supplies
  import armory_supplies
  playername = player.name.lower()
  playerlocation = player.location.lower()
#  playerinformation = player.information.upper()
  print('' + Map.zonemap[player.location][DESCRIPTION] + ' ')
  shopkeep = print("Welcome, are you interested in purchases or services?")
  answer1 = input(shopkeep)
  if answer1 in ['yes','Yes'] and player.location in ['ccccccccc']:
      player.information = 'SPEAR'
      playerinformation = player.information
#      player.open_link = True
      armory_supplies.select_purchase(playername, playerlocation, playerinformation)
  else:
    pass
  import Class
  from Class import Entity
#  with open('./Players/__pycache__/' + playername + '/' + playerlocation + '.txt','r') as file:
  with open('./Rooms/' + playerlocation + '.txt','r') as file:
    things = file.read()
    print(things)
    if len(things) == 0:
      
      prompt(playername, playerlocation)
  prompt(playername, playerlocation)




def print_location(destination, playername):

  import Map
  from Map import zonemap
  from Map import ZONENAME
  from Map import conditions
  playername = player.name.lower()
  playerlocation = player.location.lower()
  print('' + Map.zonemap[player.location][DESCRIPTION] + ' ')
  import Class
  from Class import Entity
#  with open('./Players/__pycache__/' + playername + '/' + playerlocation + '.txt','r') as file:
  with open('./Rooms/' + playerlocation + '.txt','r') as file:
    things = file.read()
    print(things)
    if len(things) == 0:
        prompt(playername, playerlocation)
  prompt(playername, playerlocation)
  
  
def movement_handler(destination, playername, playerlocation):
  i = 0
  if destination.strip():
    os.system('clear')
    player.location = destination
    i = random.randint(859, 1099)

#    if 1000 < i < 1099 or destination == 'xxxxxxxxx' or destination == 'ccccccccc' or destination == 'vvvvvvvvv' or destination == 'bbbbbbbbb' or destination == 'nnnnnnnnn':
    if 859 < i < 1099 or destination == 'xxxxxxxxx' or destination == 'ccccccccc' or destination == 'vvvvvvvvv' or destination == 'bbbbbbbbb' or destination == 'nnnnnnnnn':
      print_special_location(destination, playername)      
    else:
      alt_first_module.combat_switch()
  else:
    print('\nSorry...You cannot go that direction.\n')
    player.location = player.location
    prompt(playername, playerlocation)



def game_over(destination):
  if destination.strip():
    os.system('clear')
    playerlocation = destination
    print('' + zonemap[playerlocation][DESCRIPTION] + ' ')
    player.game_over == True
    sys.exit(0)

def player_look(playername, playerlocation):
  os.system('clear')
  import Class
  import Map
  from Map import zonemap
  from Map import ZONENAME
  from Map import conditions
#  from Map import player
  print('' + Map.zonemap[playerlocation][DESCRIPTION] + '   ')
  with open('./Rooms/' + playerlocation + '.txt','r') as file:
    things = file.readlines()
    print("Things here: \n")
    for thing in things:
      print(thing)
      prompt(playername, playerlocation)
      
      
def show(playername, playerlocation):
  playerlocation = player.location.lower()
  import Class
  print("Showing...\n\nThe things you can get: ")
  with open('./Rooms/' +  playerlocation + '.txt','r') as show_items:
    lines = show_items.read()
    if lines is None:
      print("There are no items here.\n")
    else:
      print(lines)
      prompt(playername, playerlocation)



def player_clear(myAction):
  os.system('clear')
  prompt()

def player_move(playername, playerlocation):
  import Map
  from Map import zonemap
  from Map import ZONENAME
  from Map import conditions
  print('North - South - East - West - Up - Down')
  ask = "Choose a direction: "
  destination = input(ask)
  destinations = ['north', 'south', 'east', 'west','up','down']
  if destination in ['north']:
    destination = Map.zonemap[player.location][NORTH]
    movement_handler(destination, playername, playerlocation)
  elif destination in ['south']:
    destination = Map.zonemap[player.location][SOUTH]
    movement_handler(destination, playername, playerlocation)
  elif destination in ['east']:
    destination = Map.zonemap[player.location][EAST]
    movement_handler(destination, playername, playerlocation)
  elif destination in ['west']:
    destination = Map.zonemap[player.location][WEST]
    movement_handler(destination, playername, playerlocation)
  elif destination in ['up']:
    destination = Map.zonemap[player.location][UP]
    movement_handler(destination, playername, playerlocation)
  elif destination in ['down']:
    destination = Map.zonemap[player.location][DOWN]
    movement_handler(destination, playername, playerlocation)
                     
                     


