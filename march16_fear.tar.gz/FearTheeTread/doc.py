# -*- coding: utf-8 -*-
"""Document for Python Text Adventure CMD CRUD.

Requires Python3.6
Python3.4: Not known to work.

Run command from FearTheeTread dir:
python3 fearthee_main.py

Jonathan D Engwall, gladly I acknowlege the many demonstrators and teachers
of Python coding and especially those who produced, later shared via YouTube 
Python Text Adventures.

Please report any breakability of this adventure to me at: 
engwalljonathanthereal@gmail.com so that I have the opportunity for 
corrections. This text adventure draws from every source as well as offers 
the media thorough crash protections.

Example:
    Given that the player name choice will create the necessary folder and 
    files for game play in an environment where items will not go missing 
    the following entry prevents missing or unopenable files:

        if bool(re.match("^[A-Za-z0-9]*$", playername)) == False:
          print("Use only Letters or Numbers without Whitespace.\n")
          time.sleep(0.04)
          setup_game()

    The boolen regular expression match of the character class containing 
    only numbers and letters without whitespace is quite sharp as well as 
    directly useful. Another excellent contribution is the list 
    comprehension system which dispells concerns for memory common in the 
    UNIX-esque environment of a Multi User Dungeon. 

        List comprehension:
            {'1':{ZONE:'id',DESCRIPTION:'Locality described.',EAST:'2',},}

    This collated object does nothing by itself, the magic of this list 
    is in the parsing by main.

        The parsing statement:
            print('' + zonemap[my_player.location][DESCRIPTION] + ' ')

    In this manner the player is affected by whatever conditions have 
    been applied while simply splitting a list to provide game context.
    Further context of the player make up the CRUD.

    Creation.
        abstract: a chain of small functions which may not be ideal, 
        however this being Python at present - Mar '19 - no real memory 
        management is a blessing and a curse. The Text Adventure tends 
        to overrun. Combat continues to be a challenge...

    Read and Update.
        The player object has half a dozen magic methods, so to be at 
        least a dozen. The following example is returning a length of 
        a list which has been appended onto directly before. Meaning, 
        read after write:

          def my_player_get_fights():
            my_player.name = my_player.name
            with open('./Players/' + my_player.name + '/victories.txt','r') as file:
            victories_len = file.readlines()
            fights = len(victories_len)
            return fights
    Destroy.
        As the player exits the game using the 'quit' command, the 
        player is prompted to choose to save or not as well as to save 
        location or not (it may be helpfull to return to the starting 
        point).

        No save:
            def end_game():
              playername = my_player.name
              file = open('./Lists/player_card.txt','r')
              players = file.readlines()
              remove_player = open('./Lists/player_card.txt','w+')
              for player in players:
                if player != str(playername):
                  remove_player.write(player)
                  continue
                continue
              file.close()
              remove_player.close()
              os.system("cd ./Players")
              os.system("rm -r " + str(playername) + "")
              sys.exit(0)

    An example of usefull iteration through one file opened to read for the 
    purpose of filtering the entry to be removed while writing to the same 
    file. Surely some implicit command to Python can be found to outperform 
    this.

    Enemies:
        As the player is not "anywhere" the enemies are also not "anywhere"
        in fact an enemy can be reduced to simply this:
            ai = Ai(50, 5, 'Spider', dead=False)

    With this in particular I am quite happy. I have also learned that the 
    csv reader does not need commas at all. Besides that it is possible 
    to join on nothing!

    The Reload Command:
        The player may return to the game and restart at the location from 
        which the player quit:
            for row in csv_reader:
              new_start = ('' + (f'{"".join(row)}' + ''))
              line_count += 1

    Todo:
        * Have fun remember to smile
        * Play the Tomb, visit DangerousTod on github.com
        * Work on Object Oriented State Machine to add pygame scroller
        * IF-style goblin interaction in lower dungeon
        * Add REST - EAT - BUY - SELL 
        * Consider Multi Player or Party Mode

        Jonathan Douglas Engwall - engwalljonathanthereal@gmail.com
        503-935-4277 USA
        664-860-50-69 MEXICO
"""