#######################################################################################################
#         developed by Jonathan Engwall, October of 2018 in Tijuana, MX                               #
#               PYTHON CMD CRUD MUD: FEAR THEE TREAD INTERACTIVE FICTION                              #
#         	ENGWALLJONATHANTHEREAL@GMAIL.COM **2018**                                             #
#######################################################################################################

import textwrap
import sys
sys.setrecursionlimit(10000)
import os
import re
import random
import math
import csv
import functools

from time import sleep
from FearTheeZoneMap import *

from Items import *
from Players import *
from Lists import *
from Rooms import *

screen_width = 80

combat_state = 0
combat_round = 0

#######################################################################################################
#                                                                                                     #
#                                                 generate necc txt files                             #
#######################################################################################################

def treasury_stripe(playername):
  inv = open('./Players/' + playername + '/treasuryList.txt','w+')
  with open('./Lists/treasuryList.txt','r') as file:
    basics = file.readlines()
    for basic in basics:
      inv.write(basic)
      continue
    inv.close()

def holding_stripe(playername):

  file = open('./Items/holding.txt','r')
  basics = file.readlines()
  h_inv = open('./Players/' + playername + '/holding.txt','w+')
  for basic in basics:
    h_inv.write(basic)
    continue
  file.close()
  h_inv.close()

def wearing_stripe(playername):

  file = open('./Items/wearing.txt','r')
  basics = file.readlines()
  inv = open('./Players/' + playername + '/wearing.txt','w+')
  for basic in basics:
    inv.write(basic)
    continue
  file.close()
  inv.close()
 
def clothing_stripe():
  file = open('./Lists/clothing.txt','r')
  file.close()

def weaponOrTool_stripe():
  file = open('./Lists/weaponOrTool.txt','r')
  file.close()

def treasure_stripe():
  file = open('./Lists/treasure.txt','r')
  file.close()

def player_files(playername):
  file = open('./Players/' + playername + '/wearing.txt','r')
  file.close()

def new_holding(playername):
  file = open('./Players/' + playername + '/holding.txt','r')
  file.close()

def new_inv(playername):
  file = open('./Players/' + playername + '/inventory.txt','w+')
  file.close()
  file = open('./Players/' + playername + '/inventory.txt','r')
  file.close()

def new_treas(playername):
  file = open('./Players/' + playername + '/treasuryList.txt','r')
  file.close()

def new_victories(playername):
  file = open('./Players/' + playername + '/victories.txt','w+')
  file.close()

#######################################################################################################
#                                                                                                     #
#                                          make the player                                            #
#######################################################################################################

class thing:
  def __init__(self):
    self.name = name
    self.contents = contents

class backpack:
  def __init_(thing):
    backpack.name = ''
    backpack.contents = []

class living:
  def __init__(self):
    self.name = name
    self.location = location
    self.health = health

class player:
  def __init__(living):
    player.name = ''
    player.attack = 2
    player.magic = 1
    player.health = 110
    player.location = '1_1'
    player.card = ''
    player.game_over = False

  def my_player_get_attack():
    my_player.name = my_player.name
    
    with open('./Players/' + my_player.name + '/holding.txt','r') as file:
      my_weapons = file.read()
      if '' in my_weapons:
        player.attack += 1
      if 'Bronze Sword' in my_weapons:
        player.attack += 5
      if 'Shovel' in my_weapons:
        player.attack += 6
      if 'Wand' in my_weapons:
        player.attack += 2
        player.magic += 1
############################################################################################
      if 'Axe' in my_weapons:
        player.attack += 3     
      if 'Scimitar' in my_weapons:
        player.attack += 7 
      if 'Battle Axe' in my_weapons:
        player.attack += 8
      if 'Spear' in my_weapons:
        player.attack += 6
      if 'Knife' in my_weapons:
        player.attack += 3   
      if 'Flail' in my_weapons:
        player.attack += 7
############################################################################################
      if 'Thirty Silver Coins' in my_weapons:
        player.attack += 1

      with open('./Players/' + my_player.name + '/wearing.txt','r') as file:
        my_armor = file.read()
        if '' in my_armor:
          player.attack += 1
        if 'Cloak' in my_armor:
          player.attack += 5
############################################################################################
        if 'Bronze Plate Mail' in my_armor:
          player.attack += 20
        if 'Buckler' in my_armor:
          player.attack += 5
        if 'Studded Leather' in my_armor:
          player.attack += 6
        if 'Ring Mail' in my_armor:
          player.attack += 8
        if 'Plate Mail' in my_armor:
          player.attack += 15
        if 'Elfin Chain Mail' in my_armor:
          player.attack += 11
############################################################################################
        if 'Pendant of Philemon' in my_armor:
          player.attack += 1
          player.magic += 5
        if 'Ring of Delusion' in my_armor:
          player.attack += 2
          player.magic += 1
        if 'Ring of Fire Resistance' in my_armor:
          player.attack += 6
          player.magic += 1
        if 'Ring of Mind Shielding' in my_armor:
          player.attack += 1
          player.magic += 8
        if 'Ring of Blinking' in my_armor:
          player.attack += 6
          player.magic += 1
        if 'Ring of Protection' in my_armor:
          player.attack += 4
          player.magic += 4
        if 'Ring of Human Influence' in my_armor:
          player.attack += 2
          player.magic += 5
        if 'Ring of Shocking Grasp' in my_armor:
          player.attack += 3
          player.magic += 7
        if 'Ring of Delusion' in my_armor:
          player.attack += 3
          player.magic += 2
        if 'Ring of Contrariness' in my_armor:
          player.attack += 1
          player.magic += 6
        if 'Ring of Anything' in my_armor:
          player.attack += 1
          player.magic += 3
      
        playerattack = (int(player.attack) + int(player.magic))
        return playerattack

  def my_player_get_weapon():
    my_player.name = my_player.name
    playerweapon = ''
    file = open('./Players/' + my_player.name + '/holding.txt','r')
    my_weapons = file.read()
    if '' in my_weapons:
      playerweapon = 'bare hands'
    elif 'Bronze Sword' in my_weapons:
      playerweapon = 'bronze sword'
    elif 'Shovel' in my_weapons:
      playerweapon = 'shovel'
    elif 'Wand' in my_weapons:
      playerweapon = 'wand'
############################################################################################
    elif 'Axe' in my_weapons:
      playerweapon = 'Axe'
    elif 'Scimitar' in my_weapons:
      playerweapon = 'Scimitar'
    elif 'Battle Axe' in my_weapons:
      playerweapon = 'Battle Axe'
    elif 'Spear' in my_weapons:
      playerweapon = 'Spear'
    elif 'Knife' in my_weapons:
      playerweapon = 'Knife'
    elif 'Flail' in my_weapons:
      playerweapon = 'Flail'
############################################################################################
    else:
      prompt()
    file.close()
    return playerweapon

  def my_player_get_dam_mesg():
    my_player.name = my_player.name
    player_dam_mesg = []
    file = open('./Players/' + my_player.name + '/holding.txt','r')
    my_weapons = file.read()
    if '' in my_weapons:
      player_dam_mesg = ['scratch','punch','slap']
    elif 'Bronze Sword' in my_weapons:
      player_dam_mesg = ['land a wild slash','open a deep cut','sink in a nice jab']
    elif 'Shovel' in my_weapons:
      player_dam_mesg = ['make contact with a solid whack','send a split down the middle','swing upward and land a hard smack']
    elif 'Wand' in my_weapons:
      player_dam_mesg = ['send a sizzling blast','call up a cone of freeze','summon a terrific blast']
############################################################################################
    elif 'Axe' in my_weapons:
      player_dam_mesg = ['','','']
    elif 'Scimitar' in my_weapons:
      player_dam_mesg = ['','','']
    elif 'Battle Axe' in my_weapons:
      player_dam_mesg = ['','','']
    elif 'Spear' in my_weapons:
      player_dam_mesg = ['','','']
    elif 'Knife' in my_weapons:
      player_dam_mesg = ['','','']
    elif 'Flail' in my_weapons:
      player_dam_mesg = ['','','']
############################################################################################
    else:
      prompt()
    file.close()
    return player_dam_mesg

  def my_player_get_fights():
    my_player.name = my_player.name
    with open('./Players/' + my_player.name + '/victories.txt','r') as file:
      victories_len = file.readlines()
      fights = len(victories_len)
      return fights

  def my_player_backpack_length():
    my_player.name = my_player.name
    with open('./Players/' + my_player.name + '/inventory.txt','r') as file:
      backpack_len = file.readlines()
      backpack_length = len(backpack_len)
      return backpack_length

  def my_player_inventory():
    with open('./Players/' + my_player.name + '/inventory.txt','r') as file:
      inventory = file.read()
      return inventory

  def my_player_backpack_contents():
    with open('./Players/' + my_player.name + '/inventory.txt','r') as file:
      inventory_contents = file.readlines()
      return inventory_contents

  def my_player_holding_length():
    with open('./Players/' + my_player.name + '/holding.txt','r') as file:
      holding_len = file.readlines()
      holding_length = len(holding_len)
      return holding_length

  def my_player_holding_contents():
    with open('./Players/' + my_player.name + '/holding.txt','r') as file:
      isHoldings = file.readlines()
      return isHoldings

  def my_player_holding():
    with open('./Players/' + my_player.name + '/holding.txt','r') as file:
      holding = file.read()
      return holding

  def my_player_wearing_length():
    with open('./Players/' + my_player.name + '/wearing.txt','r') as file:
      wearing_len = file.readlines()
      wearing_length = len(wearing_len)
      return wearing_length

  def my_player_wearing_contents():
    with open('./Players/' + my_player.name + '/wearing.txt','r') as file:
      isWearings = file.readlines()
      return isWearings

  def my_player_wearing():
    with open('./Players/' + my_player.name + '/wearing.txt','r') as file:
      wearing = file.read()
      return wearing

#######################################################################################################
#                                                                                                     #
#                                          enemy options and global                                   #
##############################################################################################

# ai self.death ideas:
# https://dbader.org/blog/python-dunder-methods

global ai

class Ai:
  def __init__(self, health, attack, name, dead=''):
    self.health = health
    self.attack = attack
    self.name = name
    self.dead = dead



#############################################################################################

global my_player
my_player = player()

global playername
playername = my_player.name

#######################################################################################################
#                                                                                                     #
#                                          necc. introduction art                                     #
#######################################################################################################

def restart(new_start):
#  print("restart statement\n")
  my_player.location = new_start
  playerlocation = my_player.location.lower()
#  print('\n' + my_player.location.upper() + '')
  print('' + zonemap[new_start][DESCRIPTION] + ' ')
  with open('./Players/' + my_player.name + '/' + my_player.location + '.txt','r') as file:
    things = file.readlines()
    print("Things here: \n")
    for thing in things:
      print(thing)
    main_game_loop()

def print_start_location(playername):
#  print("start statement\n")
  with open('./Players/' + my_player.name + '/startlocation.txt') as location_line:
    csv_reader = csv.reader(location_line, delimiter= ',')
    line_count = 0
    for row in csv_reader:
      new_start = ('' + (f'{"".join(row)}' + ''))
      line_count += 1
    restart(new_start)


def run_game(playername):
  my_player.name = my_player.name
  treasure_stripe()
  weaponOrTool_stripe()
  clothing_stripe()
  os.system('clear')
  welcome = "\n\n\nWelcome to the Under Kingdom\n"
  for character in welcome:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.1)

#######################################################################################################
#                                                                                                     #
#                                                desc first room                                      #
#######################################################################################################

  print('\n\nTerrible Luck!\nYou fell through a crack in the ceiling above. It is a good thing you bought all those supplies when you were in town!\n\n')
  player.location = '1_1'
  print('Oubliette.\nA crack in the ceiling above the middle of the north wall allows a trickle of water to flow down to the floor. The water pools near the base of the wall, and a rivulet runs along the wall an out into the hall. The water smells fresh.\n\n')
  print("To the South is a Door\nTo the West is a Door\n")
  with open('./Players/' + my_player.name + '/1_1.txt','r') as file:
    things = file.readlines()
    print("Things here: \n")
    for thing in things:
      print(thing)
      main_game_loop()


def list_ready(playername):
#  print("list statement\n")
  file = open('./Players/' + my_player.name + '/treasuryList.txt','r')
  file.close()
  my_player.name = my_player.name
  file = open('./Players/' + my_player.name + '/startlocation.txt','r')
  startlocation = file.read()
  file.close()
  if startlocation == 'xxxxxxxxx' or startlocation == 'ccccccccc' or startlocation == 'vvvvvvvvv' or startlocation == 'bbbbbbbbb' or startlocation == 'nnnnnnnnn' or startlocation == '1_1':
    startlocation = 1_1
#    print("1_1 restart statement\n")
    my_player.game_over = False
    run_game(playername)
  else:
#    print("print start statement\n")
    my_player.game_over = False
    print_start_location(playername)

def inv_ready(playername):
#  print("inv statement\n")
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  file.close()
  list_ready(playername)

def wear_ready(playername):
#  print("wear statement\n")
  file = open('./Players/' + my_player.name + '/wearing.txt','r')
  file.close()
  inv_ready(playername)

def hold_ready(playername):
#  print("hold statement\n")
  with open('./Players/' + my_player.name +'/holding.txt','r') as file:
    living_check = file.read()
    if 'silver skull' in living_check:
      message = "This player is dead.\n"
      file.close()
      os.system('clear')
      title_screen_message(message)
    else:
      file.close()
      wear_ready(playername)

def get_backpack_contents():
  file = open('./Lists/player_card.txt','r')
  contents = file.read()
  print(contents)
  file.close()
  my_player.name = input("\nChoose the player to resume from this list\nChoose player: \n")
  file = open('./Lists/player_card.txt','r')
  strict = file.read()
  if my_player.name == '':
    sys.exit(0)
  elif my_player.name.lower() in strict.lower():
    file.close()
    os.system('clear')
#    playername = my_player.name
    hold_ready("" + my_player.name + "")################<<<<<<<<<<<<<<<<<<<<<############,
  else:
    file.close()
    os.system('clear')
    message = "Player not found.\nRemember to match spelling and capitalization."
    title_screen_message(message)

########################################################

def title_screen_message(message):
  print('\n')
  print('' + message + '\n')
  print('WELCOME TO: ')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00 00 00000000 00000000000 00  0000000000000000 00000000000000000000000000000000')
  print('00 00 00000000 00000000000 00 00000000000000000 00000000000000000000000000000000')
  print('00 00 00000000 00000000000 0 000 00000000000000 00000000000000000000000000000000')
  print('00 00 00 000 0 000 00 0  0 000000000000000000 0 000   000 0 0 0 0 00000000000000')
  print('00 00 0 0 0 00 0 00 0  000 0 000 0 0 000 000 00 00 0000 0 000 000 00000000000000')
  print('00 00 0 0 0 00 0 0000 0000 00 00 0 00 0 00 0 00 00 0000 0 000 000 00000000000000')
  print('000  00 0 00 0000   0 0000 00  0 0 00 00 00000 0000   000 000 000 00000000000000')
  print('000000000000000000000000000000000000000000 0000000000000000000000000000000000000')
  print('0000000000000000000000000000000000000 000000000000000000000000000000000000000000')
  print('000000           NEW GAME        EXIT      or     RESUME                  000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000\n')
  title_screen_selections()

def title_screen_selections():
  choice = input("Command: ")
  while choice.lower() in ['new game','exit','resume']:
    if choice.lower() == ("exit"):
      sys.exit(0)
    elif choice == '':
      title_screen()
    elif choice.lower() == ("new game"):
      setup_game()
    elif choice.lower() == ("resume"):
      get_backpack_contents()
    else:
      title_screen()
      
    while choice.lower() not in ['new game', 'exit','resume']:
      print("Please enter a valid command: New Game - Exit - Resume")
      choice = input("Command: ")
      if choice.lower() == ("exit"):
        sys.exit(0)
      elif choice.lower() == (''):
        sys.exit(0)
      elif choice.lower() == ("new game"):
        setup_game()
      elif choice.lower() == ("resume"):
        get_backpack_contents()
      else:
        title_screen()

def title_screen():
  os.system('clear')
  print('\n')
  print('WELCOME TO: ')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000')
  print('00 00 00000000 00000000000 00  0000000000000000 00000000000000000000000000000000')
  print('00 00 00000000 00000000000 00 00000000000000000 00000000000000000000000000000000')
  print('00 00 00000000 00000000000 0 000 00000000000000 00000000000000000000000000000000')
  print('00 00 00 000 0 000 00 0  0 000000000000000000 0 000   000 0 0 0 0 00000000000000')
  print('00 00 0 0 0 00 0 00 0  000 0 000 0 0 000 000 00 00 0000 0 000 000 00000000000000')
  print('00 00 0 0 0 00 0 0000 0000 00 00 0 00 0 00 0 00 00 0000 0 000 000 00000000000000')
  print('000  00 0 00 0000   0 0000 00  0 0 00 00 00000 0000   000 000 000 00000000000000')
  print('000000000000000000000000000000000000000000 0000000000000000000000000000000000000')
  print('0000000000000000000000000000000000000 000000000000000000000000000000000000000000')
  print('000000           NEW GAME        EXIT      or     RESUME                  000000')
  print('00000000000000000000000000000000000000000000000000000000000000000000000000000000\n')
  title_screen_selections()

# '''
# ##  ##  ##   ## #### ## ## ##
# ###########  ## ########## ##
# ## ##### ##   #  ## ## ##  ##
# ### ### ###  ## #############
# ###########   #            #
# '''

ZONENAME= ''
DESCRIPTION = 'description'
EXAMINATION = 'examine'
SOLVED = False
NORTH = 'north'
SOUTH = 'south'
EAST = 'east'
WEST = 'west'
EXIT = 'escape'
DEATH = 'death'
ESCAPE = 'escape'

solved_places = {'Top Left Corner Room':False, 'Lower Left Room':False, 'Top Right Room':False, 'Lower Right Room':False, } # '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                 '':False, '':False, '':False, '':False, '':False, '':False, '':False, '':False,
#                }
#######################################################################################################
#                                                                                                     #
#                                          combat and logic for AI                                    #
#######################################################################################################

 ################################################################################
#                                                                                #
#                          OUR VILLAINS                                          #
def combat_switch():
  i = 0
  fights = player.my_player_get_fights()
  if fights < 3:
    ai = Ai(50, 5, 'Spider', dead=False)
    combat_handler(ai)
  elif fights < 8:
    ai = Ai(100, 10, 'Lizard Man', dead=False)
    combat_handler(ai)
  elif fights < 15:
    ai = Ai(200, 5, 'Grimlock', dead=False)
    combat_handler(ai)
  elif fights < 20:
    ai = Ai(400, 4, 'Azer', dead=False)
    combat_handler(ai)
  elif fights < 25:
    ai = Ai(600, 8, 'Shocker', dead=False)
    combat_handler(ai)
  elif fights < 30:
    ai = Ai(1000, 5, 'Ghoul', dead=False)
    combat_handler(ai)
  elif fights < 35:
    ai = Ai(1000, 15, 'Ogre', dead=False)
    combat_handler(ai)
  elif fights < 36:
    ai = Ai(2000, 20, 'Brass Dragon', dead=False)
    combat_handler(ai)
  if fights < 39:
    ai = Ai(500, 7, 'Purple Spider', dead=False)
    combat_handler(ai)
  elif fights < 48:
    ai = Ai(1000, 7, 'Mud Man', dead=False)
    combat_handler(ai)
  elif fights < 55:
    ai = Ai(1000, 20, 'Quickling', dead=False)
    combat_handler(ai)
  elif fights < 60:
    ai = Ai(1000, 15, 'Silver Beard', dead=False)
    combat_handler(ai)
  elif fights < 75:
    ai = Ai(3000, 18, 'Torturer', dead=False)
    combat_handler(ai)
  elif fights < 80:
    ai = Ai(1000, 50, 'Night Ghoul', dead=False)
    combat_handler(ai)
  elif fights < 95:
    ai = Ai(6000, 99, 'Lichess', dead=False)
    combat_handler(ai)
  elif fights == 100:
    ai = Ai(12000, 90, 'Green Dragon', dead=False)
    combat_handler(ai)
  else:
    ai = Ai(50, 5, 'Spider', dead=False)
    combat_handler(ai)

def combat_handler(ai):

  playername = my_player.name.lower()
  whereabouts = my_player.location.lower()
  battleground = whereabouts
  playerlocation = my_player.location.lower()
  if ai.dead == False:
    ai_fight(playername, ai, battleground, playerlocation)
  else:
    prompt()

def ai_intercept(combat_round, playername, ai, playerlocation):
  playerlocation = ai.location.lower()
  battleground = ai.location.lower()
  playerlocation = my_player.location.lower()
  print("" + str(ai.name.upper()) + " has found you!\n")
  print("The mad beast looks at you for a moment...\n")
  print( "" + str(ai.name.upper()) + " attacks!!!\n")
  combat_state = 1
  hand_to_hand_combat(combat_round, playername, ai, battleground, playerlocation)

def player_move():
  print('North - South - East - West - Up - Down')
  ask = "Choose a direction: "
  destination = input(ask)
  destinations = ['north', 'south', 'east', 'west','up','down']
  if destination in ['north']:

    destination = zonemap[my_player.location][NORTH]
    movement_handler(destination)
  elif destination in ['south']:

    destination = zonemap[my_player.location][SOUTH]
    movement_handler(destination)
  elif destination in ['east']:

    destination = zonemap[my_player.location][EAST]
    movement_handler(destination)
  elif destination in ['west']:

    destination = zonemap[my_player.location][WEST]
    movement_handler(destination)
  elif destination in ['up']:

    destination = zonemap[my_player.location][UP]
    movement_handler(destination)
  elif destination in ['down']:

    destination = zonemap[my_player.location][DOWN]
    movement_handler(destination)
  elif destination in ['escape']:

    destination = zonemap[my_player.location][EXIT]
    game_over(destination)
  else:
    print("Where is that?\nYou stay where you are.\n")

#######################################################################################################
#                                                                                                     #
#                                          combat loop basic                                          #
#######################################################################################################

def ai_fight(playername, ai, battleground, playerlocation):
  combat_round = 0
  combat_state = 1
  combat_round = combat_round
  while combat_state == 1:
    if battleground != playerlocation:
      if combat_state != 0:
        time.sleep(0.02)
        ai_intercept(combat_round, playername, ai, playerlocation)
      continue
    else:
      combat_state = 1
      hand_to_hand_combat(combat_round, playername, ai, battleground, playerlocation)
    
def hand_to_hand_combat(combat_round, playername, ai, battleground, playerlocation):
  combat_state = 1
  combat_round += 1
  playerattack = player.my_player_get_attack()
  playerweapon = player.my_player_get_weapon()
  player_dam_mesg = player.my_player_get_dam_mesg()
  while combat_state == 1:
    if my_player.health > 0:
      if ai.health > 0:
        ai.dead = False
        player_dam_math = ((int(playerattack)) * (random.randint(5, 10))) - ((int(ai.attack)) * (random.randint(3, 8)))
        ai_dam_math = ((int(ai.attack)) * (random.randint(4, 9))) - ((int(playerattack)) * (random.randint(3, 8)))
        if int(player_dam_math) < 0:
          print("You should run! The " + ai.name + " is too powerfull!")
          quarter = input("Do you want to fight or run: \n" )
          if quarter.lower() == ('fight'):
            input("Press Enter to Continue")
            my_player.health -= abs(ai_dam_math)
            print("Points of damage taken: " + str(ai_dam_math) + "")
            hand_to_hand_combat(combat_round, playername, ai, battleground, playerlocation)
           
          elif quarter.lower() == ('run'):
            ai.dead = False
            combat_state = 1
            combat_round = 0
            i = 0
            player_move()
                   
          else:
            print("Unknown command")
            print("The battle continues.\n")
            my_player.health -= abs(ai_dam_math)
            print("Points of damage taken: " + str(ai_dam_math) + "")
            hand_to_hand_combat(combat_round, playername, ai, battleground, playerlocation)
        else:
          if int(ai_dam_math) < 0:
            print("No damage.")
            ai.health -= abs(player_dam_math)
            hand_to_hand_combat(combat_round, playername, ai, battleground, playerlocation)
          else:
            my_player.health -= abs(ai_dam_math)
            print("Points of damage taken: " + str(ai_dam_math) + "")
########################################################################################################
            ai.health -= abs(player_dam_math)
            if ai.health < 0:
              ai.dead = True
              combat_state -= 1
              combat_round = 0
              i = 0
              playerlocation = battleground
              playerlocation = my_player.location.lower()
              print('' + zonemap[my_player.location][DESCRIPTION] + ' ')
              with open('./Players/' + playername + '/' + playerlocation + '.txt','r') as file:
                things = file.read()
                print("Things here: \n")
                print(thing)
                with open('./Players/' + playername + '/victories.txt','a+') as file:
                  file.write('' + ai.name + '\n')
                print("Victory!\nThe " + ai.name + " has been defeated.")
              loot_state()
            elif my_player.health < 0:
              player.game_over = True
              combat_state -= 1
              combat_round = 0
              i = 0
              with open('./Players/' + playername + '/holding.txt','w') as file:
                file.write('silver skull')
              print('What a lovely youth, still so young and strong. Such a pity...Death shakes \n' +
'his head, lifts his scythe and cuts you down...Such a pity...\n\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0+0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-+0\n'+
'0|00 HA HA HA HA 00 THE UNDER KINGDOM LAUGHS 00 HA HA HA 0000|0000000000000000|0\n'+
'000000000000000000000000000000000000000000000000000000000000| 000000000000 00000\n'+
'0|0000            00000000000000000    0000  00000000000000 000000000000000 00|0\n'+
'000000  000000000 0000000000000000000  0000  0000000000000|00     000     00|000\n'+
'0|0000  0000000000000000000000000000000 000  00000000000000000    000    00000|0\n'+
'000000  000000000    000000000 0  000000 00  000    0000000|000000000000000|0000\n'+
'0|0000  0  00000  00  00   000  000 00000   00  000  0000000  00000 00000  000|0\n'+
'000000  00000000 000000 000 00 00000000000  00 000000000000000 000   000 0000000\n'+
'0|0000  00000000 000000 000 00 00000000000  00 000000000000000|000000000|00000|0\n'+
'000000  00000000      00  00 0 00000000000   0      00000000000 | | | | 00000000\n'+
'0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n'+
'0+-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0+0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'\n\n\n\nYou go on ahead, we will wait right here...\n')
              sys.exit(0)
            else:
              mesg = random.randint(0,2)
              dam_mes = player_dam_mesg.pop(int(mesg))
              print("Points of damge you deal: " + str(player_dam_math) + "")
              print("When you " + str(dam_mes) + " with your " + playerweapon + ".")
########################################################################################################
              print("Your health: " + str(my_player.health) + "")
              print("" + ai.name + " health: " + str(ai.health) + "")
              print("Combat round: " + str(combat_round) + "")
              quarter = input("Do you want to fight or run: \n" )
              if quarter.lower() == ('fight'):
                input("Press Enter to Continue")
                hand_to_hand_combat(combat_round, playername, ai, battleground, playerlocation)
              elif quarter.lower() == ('run'):
                ai.dead = False
                combat_state = 1
                combat_round = 0
                i = 0
                player_move()                   
              else:
                print("Unknown command")
                print("The battle continues.\n")  
                hand_to_hand_combat(combat_round, playername, ai, battleground, playerlocation)
      else:
        ai.dead = True
        combat_state -= 1
        combat_round = 0
        i = 0
        playerlocation = battleground
        playerlocation = my_player.location.lower()
        print('' + zonemap[my_player.location][DESCRIPTION] + ' ')
        with open('./Players/' + playername + '/' + playerlocation + '.txt','r') as file:
          things = file.read()
          print(things)
        print("Victory!\nThe " + ai.name + " has been defeated.")
        with open('./Players/' + playername + '/victories.txt','a+') as file:
          file.write('' + ai.name + '\n')
        loot_state(playername)
    else:
      player.game_over = True
      combat_state -= 1
      combat_round = 0
      i = 0
      with open('./Players/' + playername + '/holding.txt','w') as file:
        file.write('silver skull')
      print('\nWhat a lovely youth, still so young and strong. Such a pity...Death shakes \n' +
'his head, lifts his scythe and cuts you down...Such a pity...\n\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0+0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-+0\n'+
'0|00 HA HA HA HA 00 THE UNDER KINGDOM LAUGHS 00 HA HA HA 0000|0000000000000000|0\n'+
'000000000000000000000000000000000000000000000000000000000000| 000000000000 00000\n'+
'0|0000            00000000000000000    0000  00000000000000 000000000000000 00|0\n'+
'000000  000000000 0000000000000000000  0000  0000000000000|00     000     00|000\n'+
'0|0000  0000000000000000000000000000000 000  00000000000000000    000    00000|0\n'+
'000000  000000000    000000000 0  000000 00  000    0000000|000000000000000|0000\n'+
'0|0000  0  00000  00  00   000  000 00000   00  000  0000000  00000 00000  000|0\n'+
'000000  00000000 000000 000 00 00000000000  00 000000000000000 000   000 0000000\n'+
'0|0000  00000000 000000 000 00 00000000000  00 000000000000000|000000000|00000|0\n'+
'000000  00000000      00  00 0 00000000000   0      00000000000 | | | | 00000000\n'+
'0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n'+
'0+-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0+0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'\n\n\n\nYou go on ahead, we will wait right here...\n')
      sys.exit(0)
  return

def loot_state(playername):
  fights = player.my_player_get_fights()
  print("Victories: " + str(fights) + "!\n")

#########################################################################################################
  t_int = random.randint(0,12)
  reward = ['knife','mask','trident pin','onyx elephant','cloak','copper key','bread','faded picture','broken watch','beautiful ring','wand','carved jade dragon','shirt']
#########################################################################################################
  loot = reward.pop(int(t_int))
  ai_death(playername, loot)

def ai_death(playername, loot):
  backpack_length = player.my_player_backpack_length()
  if backpack_length > 15:
    print("Your backpack is full.")
    with open('./Players/' + playername + '/' + playerlocation + '.txt','a+') as file:
      file.write('' + loot + '\n')
    prompt()
  else:
    print("For your effort you gained a " + loot + "")
    with open('./Players/' + playername + '/inventory.txt','a+') as file:
      file.write('' + loot + '\n')
    print("Your health: " + str(my_player.health) + "")
    prompt()

#######################################################################################################
#                                                                                                     #
#                                          game CMD handlers                                          #
#######################################################################################################

def print_location():
  playerlocation = my_player.location.lower()
  print('' + zonemap[my_player.location][DESCRIPTION] + ' ')
  with open('./Players/' + my_player.name + '/' + my_player.location + '.txt','r') as file:
    things = file.read()
    print(things)
  prompt()

def movement_handler(destination):
  i = 0
  if destination.strip():
    os.system('clear')
    my_player.location = destination
    i = random.randint(859, 1099)

    if 1000 < i < 1099 or destination == 'xxxxxxxxx' or destination == 'ccccccccc' or destination == 'vvvvvvvvv' or destination == 'bbbbbbbbb' or destination == 'nnnnnnnnn':
      print_location()      
    else:
      combat_switch()
  else:
    print('\nSorry...You cannot go that direction.\n')
    my_player.location = my_player.location
    prompt()

def game_over(destination):
  if destination.strip():
    os.system('clear')
    my_player.location = destination
    print('' + zonemap[my_player.location][DESCRIPTION] + ' ')
    my_player.game_over == True
    sys.exit(0)

def player_look():
  os.system('clear')
  print('' + zonemap[my_player.location][DESCRIPTION] + '   ')
  with open('./Players/' + my_player.name + '/' + my_player.location + '.txt','r') as file:
    things = file.readlines()
    print("Things here: \n")
    for thing in things:
      print(thing)
      prompt()

#######################################################################################################
#                                                                                                     #
#                                               get item function                                     #
#######################################################################################################

######################################################

#
###################################################################
#        check for empty hands + add ladder                       #                                              ######################################################
def carry_ladder(new_item):
  holding_length = player.my_player_holding_length()
  if holding_length is None:
    print("You pick up the ladder.\n")
    file = open('./Players/' + my_player.name + '/holding.txt','w+')
    file.write('a big ladder\nin both hands\n')
    file.close()
    prompt()
  else:
    print("You need both hands to carry a ladder.")
    prompt() 

######################################################
#        check redundant item                        #                                              ######################################################
def get_ladder():
  new_item = ('ladder')
  holding = player.my_player_holding()
        
  if 'ladder' in holding:
    print("You already have the ladder.\n")
    prompt()
  else:
    carry_ladder(new_item)

#######################################################################################################
#                                                                                                     #
#                                                 search function                                     #
#######################################################################################################
def search_items():
  print("Searching...\n\nThe people who lived here saved almost everything. In the clutter loosely \norganized around their mattress they left everything from torn magazine covers \nto a toilet brush.\n")
  cmd = input("If there is something specific you need just type in now: \n")

  if cmd in ('nuts and bolts','comb','toilet brush','shoe horn','reading glasses','golfer pencil','rain jacket','makeup tin','jump rope'):

#########################################################################################################
#########################################################################################################

    backpack_length = player.my_player_backpack_length()
    if backpack_length > 15:
      print("You might have seen one, but your backpack is full.")
      prompt()   
    else:
      found_item(cmd)
  else:
    print("You don't find a " + str(cmd) + " in all the mess of things.\n")
    prompt()

def found_item(cmd):

#######################################################################################################
#                                                                                                     #
#                                        update master player item list                               #
#######################################################################################################

  file = open('./Players/' + my_player.name + '/treasuryList.txt','r')
  contents = file.read() 
  if cmd in contents:
    file.close()
    file = open('./Players/' + my_player.name + '/treasuryList.txt','r')
    lines = file.readlines()
    next_file = open('./Players/' + my_player.name + '/treasuryList.txt','w')
    for line in lines:
      if line != ('' + str(cmd) + '\n'):
        next_file.write(line)
        continue
      continue
    file.close()
    next_file.close() 
    add_found_item(cmd)
  else:
    print("Something maybe amiss with your file structure.\nDo you already have a " + str(cmd) + "?\n")
    file.close()
    prompt()

def add_found_item(cmd):
  print("What luck! You find a " + str(cmd) + "!\n")
  with open('./Players/' + my_player.name + '/inventory.txt','a+') as file:
    file.write('' + str(cmd) + '\n')
    prompt()

#######################################################################################################
#                                                                                                     #
#                                                 multi item function                                #
#######################################################################################################
def get_junk():
  backpack_length = player.my_player_backpack_length()
  if backpack_length > 15:
    print("Your backpack is full.")
    prompt()   
  else:

#########################################################################################################
#########################################################################################################
    junk = ('Hat Pin\n','Locket\n','Flashlight\n','Mittens\n','Emerald\n')
#########################################################################################################
#########################################################################################################

    file = open('./Players/' + my_player.name + '/inventory.txt','r')
    my_stuff = file.readlines()
    file.close()
    file = open('./Players/' + my_player.name + '/inventory.txt','w+')
    file.writelines(my_stuff)
    file.writelines(junk)
    file.close
    prompt()

#########################################################################################################
#########################################################################################################

def try_green_key():
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  my_contents = file.read()
        
  if 'green key' in my_contents:
    file.close()
    print("You twist the key inside the lock. The door opens.\n")
    my_player.location = 'Singing_Crystals'
    print_location()
  else:
    print("This is not the correct key.\n")
    file.close
    prompt()

#########################################################################################################
#########################################################################################################

#######################################################################################################
#                                                                                                     #
#                                                 key getting function                                #
#######################################################################################################

#########################################################################################################
#########################################################################################################

def get_turquoise_key():
  
  file = open('./Players/' + my_player.name + '/inventory.txt','r')
  my_contents = file.read()

  if 'turquoise key' in my_contents:
    file.close()
    print("You already have this item.\n")
  else:
    file.close()
    backpack_length = player.my_player_backpack_length()
    if backpack_length > 15:
      print("Your backpack is full.")
      prompt()   
    else:
      print("You get the Turquoise Key from the " + my_player.location + "")
      file = open('./Players/' + my_player.name + '/inventory.txt','a+')
      file.write('turquoise key\n')
      file.close()
      prompt()

#######################################################################################################
#                                                                                                     #
#                                                 necc. specific CMDS                                 #
#######################################################################################################


def show():
  playerlocation = my_player.location.lower()

  print("Showing...\n\nThe things you can get: ")
  with open('./Players/' + my_player.name + '/' +  str(playerlocation) + '.txt','r') as show_items:
    lines = show_items.read()
    if lines is None:
      print("There are no items here.\n")
    else:
      print(lines)
      prompt()

def player_status(myAction):
  print("\nName: " + my_player.name + "")
  print("Health: " + str(my_player.health) + "\n")
  print("You are wearing:")
  wearing = player.my_player_wearing()
  print(wearing)

  print("\nAnd in your hands you have:")
  holding = player.my_player_holding()
  print(holding)
  prompt()

#######################################################################################################
#                                                                                                     #
#                                                      basic commands                                 #
#######################################################################################################

def player_clear(myAction):
  os.system('clear')
  prompt()

def player_move():
  print('North - South - East - West - Up - Down')
  ask = "Choose a direction: "
  destination = input(ask)
  destinations = ['north', 'south', 'east', 'west','up','down']
  if destination in ['north']:
    destination = zonemap[my_player.location][NORTH]
    movement_handler(destination)
  elif destination in ['south']:
    destination = zonemap[my_player.location][SOUTH]
    movement_handler(destination)
  elif destination in ['east']:
    destination = zonemap[my_player.location][EAST]
    movement_handler(destination)
  elif destination in ['west']:
    destination = zonemap[my_player.location][WEST]
    movement_handler(destination)
  elif destination in ['up']:
    destination = zonemap[my_player.location][UP]
    movement_handler(destination)
  elif destination in ['down']:
    destination = zonemap[my_player.location][DOWN]
    movement_handler(destination)

#######################################################################################################
#      here is a hard coded element                                                                   #                                              
#                                       save game                                                     #
#######################################################################################################

def load_backpack(name):
  location = my_player.location
  save_room = input("Save your current location?\nYes or No.\n")
  if save_room.lower() in 'no':
    file = open('./Players/' + name + '/startlocation.txt','w+')
    file.write('1_1')
    file.close()
    save_name(name)
  else:
    file = open('./Players/' + name + '/startlocation.txt','w+')
    file.write(location)
    file.close()
    save_name(name)

def save_name(name):
  file = open('./Lists/player_card.txt','r')
#  playername = my_player.name.lower()
  players = file.read()
  if name not in players:
    file.close()
    file = open('./Lists/player_card.txt','a+')
    file.write('\n' + name + '')
    file.close
    close_all_files()
  else:
    file.close()
    close_all_files()

def close_all_files():
  sys.exit(0)

#######################################################################################################
#                                                                                                     #                                     delete   
#                                                                                                     #
#######################################################################################################

def end_game(name):
#  playername = my_player.name
  with open('./Lists/player_card.txt','r') as file:
    players = file.readlines()
    with open('./Lists/player_card.txt','w+') as remove_player:
      for player in players:
        if player != name:
          remove_player.write(player)
          continue
        continue
  os.system("cd ./Players/")
  os.system("rm -rf " + str(name) + "")
  sys.exit(0)

#######################################################################################################
#                                                                                                     #
#                                                      prompt                                         #
#######################################################################################################

def prompt():
  print('show more - move - look - options - status - quit')
  global playerlocation
  playerlocation = my_player.location
  global playername
  global action
  action = input("Command: ")
  actions = ['climb ladder','quit','look','move','options','status','show more']
  if action.lower() not in actions:
    print('Command unrecognized.\n')
    prompt()
##################THE#ESCAPE#####################################################
  elif action.lower() == ("climb ladder"):
    if my_player.location.lower() in str('1_1'):
      holding = player.my_player_holding()
      if 'ladder' in holding:
        print('VICTORY!\n\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'0+0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-+0\n'+
'0|00 HA HA HA HA 00 THE UNDER KINGDOM LAUGHS 00 HA HA HA 0000|0000000000000000|0\n'+
'000000000000000000000000000000000000000000000000000000000000| 000000000000 00000\n'+
'0|0000            00000000000000000    0000  00000000000000 000000000000000 00|0\n'+
'000000  000000000 0000000000000000000  0000  0000000000000|00     000     00|000\n'+
'0|0000  0000000000000000000000000000000 000  00000000000000000    000    00000|0\n'+
'000000  000000000    000000000 0  000000 00  000    0000000|000000000000000|0000\n'+
'0|0000  0  00000  00  00   000  000 00000   00  000  0000000  00000 00000  000|0\n'+
'000000  00000000 000000 000 00 00000000000  00 000000000000000 000   000 0000000\n'+
'0|0000  00000000 000000 000 00 00000000000  00 000000000000000|000000000|00000|0\n'+
'000000  00000000      00  00 0 00000000000   0      00000000000 | | | | 00000000\n'+
'0|0000000000000000000000000000000000000000000000000000000000000000000000000000|0\n'+
'0+-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0+0\n'+
'00000000000000000000000000000000000000000000000000000000000000000000000000000000\n'+
'\n\n\n\nBe sure to brag about this at lunch!\n')
        sys.exit(0)
      else:
        print("In theory, yes, but you know you do not have a ladder.\n")
        prompt()
    else:
      print("You bump your head on the ceiling.\nOuch!")
      prompt()

####################################DOUBLE#CHECK#QUIT##############################################
  elif action.lower() == ("quit"):
    name = my_player.name.lower()
    quit_logo = input("Save Game For You?\nYes or No: \n")
    if quit_logo.lower() in ('yes'):
      load_backpack()
    else:
      print("Warning: Any reply other than 'yes' will delete your player completely!!!\n")
      secure_quit = input("Yes to save this player and progress!!!\n")
      if secure_quit.lower() in ('yes'):
        load_backpack(name)
      else:
        end_game(name)
###################################################################################################
  elif action.lower() in ['move']:
    player_move()
    return
  elif action.lower() in ['look']:
    player_look()
  elif action.lower() in ['options']:
    player_options(action.lower())
    return
  elif action.lower() in ['status']:
    player_status(action.lower())
    return
  elif action.lower() in ['show more']:
    show()

#######################################################################################################
#                                                                                                     #
#                                                 character CRUD                                      #
#######################################################################################################

def append_wear(clothing_c, inventory, playerlocation):
  isWearings = player.my_player_wearing_contents()
  wearing_length = player.my_player_wearing_length()
  
  if clothing_c in isWearings:
    print("You already are wearing your " + clothing_c + "") 

    prompt()
  elif wearing_length > 10:
    print("You can't possibly wear more than eleven things at a time.\nDrop something if you need add a garment.")

    prompt()
    
  else:
    line_write_file = open('./Players/' + my_player.name + '/inventory.txt','w')
    for isWearing in isWearings:
      if  isWearing != ('' + str(clothing_c) + '\n'):
        line_write_file.write(isWearing)
        continue
      continue
    line_write_file.close()
    file = open('./Players/' + my_player.name + '/wearing.txt','a+')
    file.write('' + str(clothing_c) + '\n')
    file.close()
    print("You wear your " + clothing_c + '')
    prompt()

def append_WorT(weapon_or_tool_c, playerlocation):
  isHoldings = player.my_player_holding_contents()
  holding_length = player.my_player_holding_length()
  backpack_contents = player.my_player_backpack_contents()
  if weapon_or_tool_c in isHoldings:
    print("" + weapon_or_tool_c + " is already in your hands.")
    return
  elif holding_length > 1:
    print("You only have two hands.")
    prompt()
    
  else:
###############DIRECT#UPDATE#PROTOCOL##############################################
    
    line_write_file = open('./Players/' + my_player.name + '/inventory.txt','w')
    for backpack_content in backpack_contents:
      if backpack_content != ('' + str(weapon_or_tool_c) + '\n'):
        line_write_file.write(backpack_content)
        continue
      continue
    line_write_file.close()
###################################################################################
    with open('./Players/' + my_player.name + '/holding.txt','a+') as file:
      file.write('' + str(weapon_or_tool_c) + '\n')
      file.close()
      print("Your " + weapon_or_tool_c + " is in your hands.")
      prompt()

def take_item(want, playerlocation):

  with open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt','r') as file:
    lines = file.readlines()
    next_file = open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt','w')
    for line in lines:
      if line != ('' + str(want) + '\n'):
        next_file.write(line)
        continue
      continue
    next_file.close()
    append_inventory(want, playerlocation)
  
def append_inventory(want, playerlocation):

  print("You take the " + want + "")
  file = open('./Players/' + my_player.name + '/inventory.txt','a+')
  file.write('' + str(want) + '\n')
  file.close()
  prompt()

def update_room_contents(drop_item, playerlocation):
    with open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt') as file:
      l = list(file)
      with open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt','w+') as output:
        output.write(str('' + drop_item + '\n'))
        for line in l:
          output.write(line)
          continue 
    prompt()

def drop_wearing(drop_item, playerlocation):

  isWearings = player.my_player_wearing_contents()    
  next_file = open('./Players/' + my_player.name + '/wearing.txt','w')

  for isWearing in isWearings:
    if isWearing != ('' + str(drop_item) + '\n'):
      next_file.write(w_line)
      continue         
    continue
    
  file.close()
  next_file.close()
  print("You drop your " + str(drop_item) + "")
  update_room_contents(drop_item, playerlocation)

def drop_holding(drop_item, playerlocation): 
 
  isHoldings = player.my_player_wearing_contents()
  next_file = open('./Players/' + my_player.name + '/holding.txt','w')
  for isHolding in isHoldings:
    if isHolding != ('' + str(drop_item) + '\n'):
      next_file.write(h_line)
      continue
    continue
  next_file.close()
  print("You drop your " + str(drop_item) + "")
  update_room_contents(drop_item, playerlocation)

def drop_backpack(drop_item, inventory, playerlocation):

  backpack_contents = player.my_player_backpack_contents()
  next_file = open('./Players/' + my_player.name + '/inventory.txt','w')
  for backpack_content in backpack_contents:
    if backpack_content != ('' + str(drop_item) + '\n'):
      next_file.write(backpack_content)
      continue
    continue
  next_file.close()
  print("You drop your " + str(drop_item) + "")
  update_room_contents(drop_item, playerlocation)

def inventory_commands(myDecisionX):
  playerlocation = my_player.location.lower()
  inventory = player.my_player_inventory()
  backpack_length = player.my_player_backpack_length()
  wearing = player.my_player_wearing_contents()
  holding = player.my_player_holding_contents()

  print('\nget - wear - hold - drop -  go back')
  global inventX
  inventX = input("Inventory Command: ")
  if inventX.lower() not in ['get', 'wear', 'hold', 'drop', 'go back']:
    print("Unknown command. ")
    prompt()
  elif inventX.lower() == ('go back'):
    os.system('clear')
    prompt()
  elif inventX.lower() == 'get':  
    if backpack_length > 15:
      print("Your backpack is full. You cannot get a new item.")
      prompt()
    else:
      with open('./Players/' + my_player.name + '/' + str(playerlocation) + '.txt', 'r') as file:
        room_contents = file.read()
        if room_contents is None:
          print("There is nothing here to get.\n")
          prompt()
        else:
          print(room_contents)
          global want
          want = input("What do you want to get: " )
          if want.lower() == ('go back'):
            os.system('clear')
            prompt()

          elif want not in room_contents:
            print("Where do you see that?\n")
            prompt()
          elif want in room_contents:
            if want in inventory:
              print("You already have one of these.\n")
              prompt()
            else:
              take_item(want, playerlocation)
          else:
            print("This " + str (want) + " you want so bad might not exist\n")
            prompt()

  elif inventX.lower() == 'wear':
    print('\n')
    if inventory is None:
      print("You have no extra items.\n")
    else:
      print(inventory)

      global clothing_c
      clothing_c = input("What do you want to wear: ")
      if clothing_c.lower() == ('go back'):
        os.system('clear')
        prompt()
      elif clothing_c not in inventory:
        print("You don't have one of those.\n")
        prompt()
      else:
        with open('./Lists/clothing.txt','r') as file:
          isGarment = file.read()
          if clothing_c in isGarment:
            append_wear(clothing_c, inventory, playerlocation)
          else:
            print("That is not something you can wear.")
            prompt()
          
  elif inventX.lower() == 'hold':    
    print('\n')
    if inventory is None:
      print("You have no extra items.\n")
    else:
      print(inventory)
      global tool_or_weapon_c
      tool_or_weapon_c = input("What do you want to have in your hands: ")
      if tool_or_weapon_c.lower() == ('go back'):
        os.system('clear')
        prompt()
      elif tool_or_weapon_c in inventory:
        with open('./Lists/weaponOrTool.txt','r') as file:
          isWorT = file.read()
          if tool_or_weapon_c in isWorT:
            append_WorT(tool_or_weapon_c, playerlocation)
          else:
            print("That is not a hand held implement.")
            prompt()
      else:
        print("You don't have one of those.\n")
        prompt()

  elif inventX.lower() == 'drop':
    global drop_item
    choice = input("Select 'backpack', 'holding', or 'wearing': ")
    if choice.lower() == ('backpack'):
      if inventory is None:
        print("Your backpack is empty.\n")
      else:
        print("In your backpack you have: \n")
        print(inventory)
        drop_item = input("Choose item: ")
        if drop_item in inventory:
          drop_backpack(drop_item, inventory, playerlocation)
        else:
          print("You do not have one of those.\n")
          prompt()

    elif choice.lower() == ('holding'):
      player.my_player_holding()
      print("In your hands you have: \n")
      if holding is None:
        print("Your hands are empty.\n")
      else:
        print(holding)
        drop_item = input("Choose item: ")
        if drop_item in holding:
          drop_holding(drop_item, playerlocation)
        else:
          print("You don't have one of those.\n")
          prompt()

    elif choice.lower() == ('wearing'):      
      print("You are wearing: \n")
      if wearing is None:
        print("It seems that you are naked.\n")
      else:
        print(wearing)
        drop_item = input("Choose item: ")
        if drop_item == 'backpack':
          print("You cannot drop your backpack.\n")
          prompt()
        else:
          if drop_item in wearing:
            drop_wearing(drop_item, playerlocation)
          else:
            print("You don't have one of those.\n")
            prompt()
    else:
      os.system('clear')
      print("Chioce is not understood.\n")
      prompt()

def player_options(myAction):
  os.system('clear')
  print('inventory - inventory commands - go back')
  opt = "Choose an option: "
  global decisionX
  decisionX = input(opt)
  if decisionX.lower() not in ['inventory', 'inventory commands','go back']:
    print("Unknown command. ")
    prompt()
  elif decisionX.lower() == ('go back'):
    os.system('clear')
    prompt()
  elif decisionX.lower() == ('inventory'):
    print("You have the following in your backpack...\n")
    inventory = player.my_player_inventory()
    print(inventory)
    prompt()

  else: 
    decisionX.lower() == ('inventory commands')
    inventory_commands(decisionX)

#######################################################################################################
#                                                                                                     #
#                                                 set up and main                                     #
#######################################################################################################

def main_game_loop():
  while my_player.game_over is False:
    prompt()

def setup_game():
  question = "Greetings adventurer. What's your name?\n"
  for character in question:
    sys.stdout.write(character)
    sys.stdout.flush()
    time.sleep(0.05)
  entry = input("Your Name: ")
  if bool(re.match("^[A-Za-z0-9]*$", entry)) == False:
    print("Use only Letters or Numbers without Whitespace.\n")
    time.sleep(0.04)
    setup_game()
  if entry == '':
    print("Use Letters or Numbers to create your playername.\n")
    time.sleep(0.04)
    setup_game()
  else:
    welcome = "Okay, " + entry + " let's begin. You need to know a few things.\n"
    for character in welcome:
      sys.stdout.write(character)
      sys.stdout.flush()
      time.sleep(0.03)

    help = "### Verbs are available and certain language processing. The basic CMDS \n" 
    help1 = "### are: look, get, drop, hold, show more, challenges, and move. You \n"
    help2 = "### have a certain amount of Health, check this with: status, and you \n"
    help3 = "### can only explore Underkingdom for a certain amount of time. Use: \n"
    help4 = "### clock to make sure you do not get trapped!\n\n"
    help5 = "### If you do get stuck, you can quit and start again at the beginning. \n"
    help6 = "### Set your terminal at 80x30. And remember it is just a game!\n\n"
    for character in help:
      sys.stdout.write(character)
      sys.stdout.flush()
      time.sleep(0.04)
    for character in help1:
      sys.stdout.write(character)
      sys.stdout.flush()
      time.sleep(0.04)
    for character in help2:
      sys.stdout.write(character)
      sys.stdout.flush()
      time.sleep(0.04)
    for character in help3:
      sys.stdout.write(character)
      sys.stdout.flush()
      time.sleep(0.04)
    for character in help4:
      sys.stdout.write(character)
      sys.stdout.flush()
      time.sleep(0.04)
    for character in help5:
      sys.stdout.write(character)
      sys.stdout.flush()
      time.sleep(0.04)
    for character in help6:
      sys.stdout.write(character)
      sys.stdout.flush()
      time.sleep(0.04)

    goodluck = "\n\n\nOkay, " + entry + " you will be you and the clock starts ticking now!!!\n"
    for character in goodluck:
      sys.stdout.write(character)
      sys.stdout.flush()
      time.sleep(0.08) # was time.sleep(0.08)
      os.system('clear')
      os.system("mkdir ./Players/" + entry) 
      os.system("cd ./Players/" + entry)
      os.system("touch __init__.py")
      os.system("cd ..")
      os.system("cp -r ./Rooms/* ./Players/" + entry)
      treasury_stripe(entry)
      holding_stripe(entry)
      wearing_stripe(entry)
      player_files(entry)
      new_holding(entry)
      new_inv(entry)
      new_treas(entry)
      new_victories(entry)
      run_intro(entry)
#      run_game(playername)

################################################################

def run_intro(entry):
  my_player.name = entry
  treasure_stripe()
  weaponOrTool_stripe()
  clothing_stripe()
  os.system('clear')
#  welcome = "\n\n\nWelcome to the Under Kingdom\n"
#  for character in welcome:
#    sys.stdout.write(character)
#    sys.stdout.flush()
#    time.sleep(0.1)

#######################################################################################################
#                                                                                                     #
#                                                desc first room                                      #
#######################################################################################################

  print('\n\nWelcome to the Border Land!\nWhat adventure awaits!\n\n')
  player.location = 'xxxxxxxxx'
  print('Pinklemire Street.\n.\n\n')
  print("To the North is the Blacksmith\nTo the South is the Message Post\nTo the East is the Leather Shop\nTo the West is the Pub\n")
  with open('./Players/' + my_player.name + '/xxxxxxxxx.txt','r+') as file:
    things = file.readlines()
    print("Things here: \n")
    for thing in things:
      print(thing)
    main_game_loop()


################################################################

title_screen()
